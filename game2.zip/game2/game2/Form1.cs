﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace game2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            label1.Tag = "1";
            if (label1.Tag == label6.Tag)
            {
                label1.Visible = false;
                label6.Visible = false;
            }
            else
            {
                label6.Tag = "";
                label2.Tag = "";
                label5.Tag = "";
                label3.Tag = "";
                label4.Tag = "";


            }

        }

        private void label6_Click(object sender, EventArgs e)
        {
            label6.Tag = "1";
            if (label6.Tag == label1.Tag)
            {
                label1.Visible = false;
                label6.Visible = false;
            }
            else
            {
                label1.Tag = "";
                label2.Tag = "";
                label5.Tag = "";
                label3.Tag = "";
                label4.Tag = "";

            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            label2.Tag = "2";
            if (label2.Tag == label5.Tag)
            {
                label2.Visible = false;
                label5.Visible = false;

            }
            else
            {
                label5.Tag = "";
                label1.Tag = "";
                label6.Tag = "";
                label3.Tag = "";
                label4.Tag = "";


            }
        }

        private void label5_Click(object sender, EventArgs e)
        {
            label5.Tag = "2";
            if (label5.Tag == label2.Tag)
            {
                label2.Visible = false;
                label5.Visible = false;
            }
            else
            {
                label2.Tag = "";
                label6.Tag = "";
                label1.Tag = "";
                label3.Tag = "";
                label4.Tag = "";


            }


        }

        private void label3_Click(object sender, EventArgs e)
        {
            label3.Tag = "3";
            if (label3.Tag == label4.Tag)
            {
                label3.Visible = false;
                label4.Visible = false;
            }
            else
            {
                label1.Tag = "";
                label2.Tag = "";
                label4.Tag = "";
                label5.Tag = "";
                label6.Tag = "";

            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            label4.Tag = "3";
            if (label4.Tag == label3.Tag)
            {
                label4.Visible = false;
                label3.Visible = false;
            }
            else
            {
                label1.Tag = "";
                label2.Tag = "";
                label3.Tag = "";
                label5.Tag = "";
                label6.Tag = "";


            }
        }
    }
}