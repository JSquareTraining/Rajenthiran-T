create table employee (e_id nvarchar(10)primary key,e_name nvarchar(20),gender nvarchar(10),address1 nvarchar(20),city nvarchar(20),
phone_number numeric(20)not null,e_mail_id nvarchar(20)not null)
select * from REG
CREATE TABLE REG (SNAME NVARCHAR(30),PASSWORD1 NVARCHAR(20),NATIVE1 NVARCHAR(20),DATA_OF_BIRTH NVARCHAR(20),PHONENO NVARCHAR(20),MAI_ID NVARCHAR(30))
create table std2 (sno nvarchar(10),sname nvarchar(20),city nvarchar(30))
insert into offer values('1','raja','city')
create table offer(product_name nvarchar(3),offer_name nvarchar(50),offer_duration nvarchar(20))
select * from offer
SELECT * FROM product
delete category
delete grid
alter table offer alter column product_name nvarchar(30)
drop table grid
create table grid(name nvarchar(20),mark nvarchar(20),city nvarchar(20))
insert into grid values('raja','40','rmd')
select sub_category from product where sub_category like '%%'
create table again(name nvarchar(20),mark1 numeric(10),mark2 numeric(10))
insert into again values('raja',50,60)