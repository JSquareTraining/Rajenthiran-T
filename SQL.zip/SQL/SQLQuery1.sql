select * from employee
alter table employee add department nvarchar(20)
delete employee