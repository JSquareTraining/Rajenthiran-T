create table test13(name nvarchar(30),city nvarchar(30),state nvarchar(30),nationality nvarchar(30),mailid nvarchar(30))
select * from test13
alter procedure test133
(@name       nvarchar(30),
@city        nvarchar(30),
@state       nvarchar(30),
@nationality nvarchar(30),
@mailid      nvarchar(30))
as
begin
if exists(select * from sys.tables st join sys.columns sc on sc.object_id=st.object_id where st.name='test13' and sc.name='name')
 begin
 insert into test13 values(@name,@city,@state,@nationality,@mailid)
 end
 else
 begin
 print 'sorry not have table'
 end
 
end       

execute test133 'raja','rmd','tamil','ind','raja@gmail.com' 
select * from test13