create database flipkart
create table login1(username nvarchar(30),password1 nvarchar(30))
insert into login1 values('admin','12345')
select * from login1
select password1 from login1

create table product(main_caegory    nvarchar(50),
                    sub_category     nvarchar(50),
                    product_name     nvarchar(50),
                    purchase_price   numeric(10),
                    sales_price      numeric(10),
                    stock            numeric(10),
                    feature          nvarchar(100),
                    image_upload     nvarchar(300))
                    
 alter proc product_proc 
 
                    @main_category   nvarchar(50),
                    @subcategory     nvarchar(50),
                    @product_name    nvarchar(50),
                    @purchase_price  nvarchar(10),
                    @sales_price     nvarchar(10),
                    @stock           nvarchar(10),
                    @feature         nvarchar(100),
                    @image_upload    nvarchar(100)
 as
 begin
     insert into product values(@main_category,@subcategory,@product_name,@purchase_price,@sales_price,
                                @stock,@feature,@image_upload)
 
     
 end
product_proc 'sa','fss','fs',30,34,5,'fff','fsf'          

select * from product
truncate table product
begin transaction dd
delete from product
rollback transaction dd
COMMIT transaction dd


-------product-----

