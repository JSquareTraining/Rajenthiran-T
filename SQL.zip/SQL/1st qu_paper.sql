create table salesperson
(
id int primary key,
name nvarchar(20),
age int,
salary nvarchar(10),
gender nvarchar(20)
)
alter table salesperson alter column salary numeric(10)

insert into salesperson values(11,'joe',38,38000,'f')
create table customer
(
id int primary key,
name nvarchar(20),
city nvarchar(20),
industry_type nvarchar(30)
)
insert into customer values(9,'orange','jackson','b')


create table orders
(
number int,
order_date datetime,
cus_id int references customer (id),
sal_id int references salesperson(id),
amount int
) 
alter table orders drop column city
alter table orders alter column amount nvarchar(10)

insert into orders values(70,5/6/98,9,7,150)
---------------------------
create table codemaster
(
code_name nvarchar(20),
code_value nvarchar(10),
code_description nvarchar(20)
) 
insert into codemaster values('gender','m','male')
select * from customer
select * from salesperson
select * from orders
select * from codemaster

-----get the names of all salespeople that have an order with samsonic-----
select distinct c.id,o.cus_id,o.sal_id,s.name from customer as c inner join orders  as o  on c.id=o.cus_id inner join salesperson  as s on s.id=o.sal_id inner join orders as oo on o.cus_id =oo.cus_id where c.name='samsonic' 
select  COUNT from  orders  where sal_id >=2
2 
select distinct s.name from orders as o inner join salesperson as s on sal_id=id where sal_id>2
 
select COUNT (*),sal_id from orders   where cus_id >=2 group by sal_id
3
select name,age into highAchiever    from salesperson  where salary >100000 
10
select SUM (salary)from salesperson where age between 30 and  50 
select SUM (amount)sal_id from orders group by sal_id

select MAX (amount) from orders
11
----dis the salsper records who has the recent order----
select SUM (amount)cus_id,sal_id  from orders 
select*from orders where sal_id=
select distinct * from customer,salesperson,orders where city ='jackson'
----------------------------------------------------------------------------------------------------------------------

select distinct c.id,o.cus_id,o.sal_id ,s.name from customer as c inner join orders as o on c.id=o.cus_id inner join salesperson as s on s.id=o.sal_id inner join orders as oo on o.cus_id=oo.cus_id where c.name='samsonic'



