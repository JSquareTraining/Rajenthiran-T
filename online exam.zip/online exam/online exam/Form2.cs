﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;

namespace online_exam
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton20_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton19_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton18_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton17_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form5 f5 = new Form5();
            Form f1 = new Form5();
            Form2 f2 = new Form2();
            Form3 f3 = new Form3();
            Form4 f4 = new Form4();

            Properties.Settings on = new Properties.Settings();
            ResourceManager rm1 = new ResourceManager("online_exam.Properties.Resources", Assembly.GetExecutingAssembly());
            
                if (radioButton1.Checked == true)
                {

                    f2.label7.BackColor = Color.Green;
                    
                }
                else
                {
                    f2.label7.BackColor = Color.Red;
                    
                
                }
                if (radioButton7.Checked == true)
                {
                    f2.label8.BackColor = Color.Green;
                    
                }
                else
                {
                    f2.label8.BackColor = Color.Red;
                   
                
                                    
                }
                if (radioButton12.Checked == true)
                {
                    f2.label9.BackColor = Color.Green;
                    
                }
                else
                {
                    f2.label9.BackColor = Color.Red;
                  

                     }

                if (radioButton15.Checked == true)
                {
                    f2.label10.BackColor = Color.Green;
                    
                }
                else
                {
                    f2.label10.BackColor = Color.Red;
                    
                }
                if (radioButton19.Checked == true)
                {
                    f2.label11.BackColor = Color.Green;
                    
                }
                else
                {
                    f2.label11.BackColor = Color.Red;
                  
                }
           
    

            if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == true)
            {
                if (on.cpp == "1")
                {
                    f3.label1.Text = rm1.GetString("qa");
                    f3.label2.Text = rm1.GetString("qb");
                    f3.label3.Text = rm1.GetString("qc");
                    f3.label4.Text = rm1.GetString("qd");
                    f3.label5.Text = rm1.GetString("qe");
                    f3.radioButton3.Text = rm1.GetString("aa");
                    f3.radioButton6.Text = rm1.GetString("ab");
                    f3.radioButton11.Text = rm1.GetString("ac");
                    f3.radioButton16.Text = rm1.GetString("ad");
                    f3.radioButton20.Text = rm1.GetString("ae");
                    on.cpp = "2";
                    on.Save();
                    }
                else if (on.cpp == "2")
                {
                    f3.label1.Text = rm1.GetString("qf");
                    f3.label2.Text = rm1.GetString("qg");
                    f3.label3.Text = rm1.GetString("qh");
                    f3.label4.Text = rm1.GetString("qi");
                    f3.label5.Text = rm1.GetString("qj");
                    f3.radioButton3.Text = rm1.GetString("af");
                    f3.radioButton6.Text = rm1.GetString("ag");
                    f3.radioButton11.Text = rm1.GetString("ah");
                    f3.radioButton16.Text = rm1.GetString("ai");
                    f3.radioButton20.Text = rm1.GetString("aj");
                    on.cpp = "3";
                    on.Save();
                    

                }
                else if (on.cpp == "3")
                {
                    f3.label1.Text = rm1.GetString("qk");
                    f3.label2.Text = rm1.GetString("ql");
                    f3.label3.Text = rm1.GetString("qm");
                    f3.label4.Text = rm1.GetString("qn");
                    f3.label5.Text = rm1.GetString("qo");
                    f3.radioButton3.Text = rm1.GetString("ak");
                    f3.radioButton6.Text = rm1.GetString("al");
                    f3.radioButton11.Text = rm1.GetString("am");
                    f3.radioButton16.Text = rm1.GetString("an");
                    f3.radioButton20.Text = rm1.GetString("ao");
                    on.cpp = "1";
                    on.Save();
                    }
                if (radioButton1.Checked == true)
                {

                    f3.label12.BackColor = Color.Green;

                }
                else
                {
                    f3.label12.BackColor = Color.Red;


                }
                if (radioButton7.Checked == true)
                {
                    f3.label13.BackColor = Color.Green;

                }
                else
                {
                    f3.label13.BackColor = Color.Red;



                }
                if (radioButton12.Checked == true)
                {
                    f3.label14.BackColor = Color.Green;

                }
                else
                {
                    f3.label14.BackColor = Color.Red;


                }

                if (radioButton15.Checked == true)
                {
                    f3.label15.BackColor = Color.Green;

                }
                else
                {
                    f3.label15.BackColor = Color.Red;

                }
                if (radioButton19.Checked == true)
                {
                    f3.label16.BackColor = Color.Green;

                }
                else
                {
                    f3.label16.BackColor = Color.Red;

                }
           
    

               
                f3.checkBox1.Checked = true;
                f3.checkBox2.Checked = true;
                f3.checkBox3.Checked = true;
                f3.Show();
            }


            
           if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == false)
            {
                if (on.cpp == "1")
                {
                    f3.label1.Text = rm1.GetString("qa");
                    f3.label2.Text = rm1.GetString("qb");
                    f3.label3.Text = rm1.GetString("qc");
                    f3.label4.Text = rm1.GetString("qd");
                    f3.label5.Text = rm1.GetString("qe");
                    f3.radioButton3.Text = rm1.GetString("aa");
                    f3.radioButton6.Text = rm1.GetString("ab");
                    f3.radioButton11.Text = rm1.GetString("ac");
                    f3.radioButton16.Text = rm1.GetString("ad");
                    f3.radioButton20.Text = rm1.GetString("ae");
                    on.cpp = "2";
                    on.Save();
                }
                else if (on.cpp == "2")
                {
                    f3.label1.Text = rm1.GetString("qf");
                    f3.label2.Text = rm1.GetString("qg");
                    f3.label3.Text = rm1.GetString("qh");
                    f3.label4.Text = rm1.GetString("qi");
                    f3.label5.Text = rm1.GetString("qj");
                    f3.radioButton3.Text = rm1.GetString("af");
                    f3.radioButton6.Text = rm1.GetString("ag");
                    f3.radioButton11.Text = rm1.GetString("ah");
                    f3.radioButton16.Text = rm1.GetString("ai");
                    f3.radioButton20.Text = rm1.GetString("aj");
                    on.cpp = "3";
                    on.Save();


                }
                else if (on.cpp == "3")
                {
                    f3.label1.Text = rm1.GetString("qk");
                    f3.label2.Text = rm1.GetString("ql");
                    f3.label3.Text = rm1.GetString("qm");
                    f3.label4.Text = rm1.GetString("qn");
                    f3.label5.Text = rm1.GetString("qo");
                    f3.radioButton3.Text = rm1.GetString("ak");
                    f3.radioButton6.Text = rm1.GetString("al");
                    f3.radioButton11.Text = rm1.GetString("am");
                    f3.radioButton16.Text = rm1.GetString("an");
                    f3.radioButton20.Text = rm1.GetString("ao");
                    on.cpp = "1";
                    on.Save();
                }
               
                f3.checkBox1.Checked = true;
                f3.checkBox2.Checked = true;
                f3.checkBox3.Checked = false;
                f3.label7.BackColor = f2.label7.BackColor;
                f3.label8.BackColor = f2.label8.BackColor;
                f3.label9.BackColor = f2.label9.BackColor;
                f3.label10.BackColor = f2.label10.BackColor;
                f3.label11.BackColor = f2.label11.BackColor;

                f3.Show();
            }
             if (checkBox1.Checked == true && checkBox2.Checked ==false  && checkBox3.Checked == false)
            {
                f3.checkBox1.Checked = true;
                f3.checkBox2.Checked = false;
                f3.checkBox3.Checked = false;
                f5.label3.BackColor = f2.label7.BackColor;
                f5.label4.BackColor = f2.label8.BackColor;
                f5.label5.BackColor = f2.label9.BackColor;
                f5.label6.BackColor = f2.label10.BackColor;
                f5.label7.BackColor = f2.label11.BackColor;

                
                
                f5.Show();
            }
             else if (checkBox1.Checked == true && checkBox2.Checked == false && checkBox3.Checked == true)
             {
                 ResourceManager rm2 = new ResourceManager("online_exam.net", Assembly.GetExecutingAssembly());

                 if (on.c == "1")
                 {
                     f4.label1.Text = rm2.GetString("na");
                     f4.label2.Text = rm2.GetString("nb");
                     f4.label3.Text = rm2.GetString("nc");
                     f4.label4.Text = rm2.GetString("nd");
                     f4.label5.Text = rm2.GetString("ne");

                     f4.radioButton1.Text = rm2.GetString("aa");
                     f4.radioButton7.Text = rm2.GetString("ab");
                     f4.radioButton10.Text = rm2.GetString("ac");
                     f4.radioButton13.Text = rm2.GetString("ad");
                     f4.radioButton19.Text = rm2.GetString("ae");
                     on.c = "2";
                     on.Save();
                     f4.Show();
                 }
                 else if (on.c == "2")
                 {
                     f4.label1.Text = rm2.GetString("nf");
                     f4.label2.Text = rm2.GetString("ng");
                     f4.label3.Text = rm2.GetString("nh");
                     f4.label4.Text = rm2.GetString("ni");
                     f4.label5.Text = rm2.GetString("nj");

                     f4.radioButton1.Text = rm2.GetString("af");
                     f4.radioButton7.Text = rm2.GetString("ag");
                     f4.radioButton10.Text = rm2.GetString("ah");
                     f4.radioButton13.Text = rm2.GetString("ai");
                     f4.radioButton19.Text = rm2.GetString("aj");
                     on.c = "3";
                     on.Save();
                     f4.Show();
                 }
                 else if (on.c == "3")
                 {
                     f4.label1.Text = rm2.GetString("nk");
                     f4.label2.Text = rm2.GetString("nl");
                     f4.label3.Text = rm2.GetString("nm");
                     f4.label4.Text = rm2.GetString("nn");
                     f4.label5.Text = rm2.GetString("no");

                     f4.radioButton1.Text = rm2.GetString("ak");
                     f4.radioButton7.Text = rm2.GetString("al");
                     f4.radioButton10.Text = rm2.GetString("am");
                     f4.radioButton13.Text = rm2.GetString("an");
                     f4.radioButton19.Text = rm2.GetString("ao");
                     on.c = "1";
                     on.Save();
                 }
                 f4.checkBox1.Checked = true;
                 f4.checkBox2.Checked = false;
                 f4.checkBox3.Checked = true;
                 f4.Show();

                

                 f4.checkBox1.Checked = true;
                 f4.checkBox2.Checked = false;
                 f4.checkBox3.Checked = true;
                 f4.label7.BackColor = f2.label7.BackColor;
                 f4.label8.BackColor = f2.label8.BackColor;
                 f4.label9.BackColor = f2.label9.BackColor;
                 f4.label10.BackColor = f2.label10.BackColor;
                 f4.label11.BackColor = f2.label11.BackColor;


                 f4.Show();

             }
             else if (checkBox1.Checked == true && checkBox2.Checked ==false && checkBox3.Checked == true)
             {
                 f4.checkBox1.Checked = true;
                 f4.checkBox2.Checked = false;
                 f4.checkBox3.Checked = true;
                 f3.label7.BackColor = f2.label7.BackColor;
                 f3.label8.BackColor = f2.label8.BackColor;
                 f3.label9.BackColor = f2.label9.BackColor;
                 f3.label10.BackColor = f2.label10.BackColor;
                 f3.label11.BackColor = f2.label11.BackColor;


                 f4.Show();
             }

             f4.checkBox1.Checked = true;
             f4.checkBox2.Checked = false;
             f4.checkBox3.Checked = true;
                 

                 
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

    }
}
