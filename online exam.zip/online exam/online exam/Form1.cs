﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;
namespace online_exam
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }
        Properties.Settings on = new Properties.Settings();

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
       
        

        private void button1_Click(object sender, EventArgs e)
        {

            Form2 f2 = new Form2();
            Form5 f5 = new Form5();

            Form3 f3 = new Form3();
            Form4 f4 = new Form4();
             ResourceManager rm2 = new ResourceManager("online_exam.net", Assembly.GetExecutingAssembly());
             ResourceManager rm1 = new ResourceManager("online_exam.Properties.Resources", Assembly.GetExecutingAssembly());
           
           

            //Properties.Settings on = new Properties.Settings();
           // ResourceManager rm = new ResourceManager("online exam.properties.resouces1", Assembly.GetExecutingAssembly());

            if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == true)
            {
               //
                
                if (on.c == "1")
                {
                    ResourceManager rm = new ResourceManager("online_exam.properties.resource1", Assembly.GetExecutingAssembly());
                    f2.label1.Text = rm.GetString("cqa");
                    f2.label2.Text = rm.GetString("cqb");
                    f2.label3.Text = rm.GetString("cqc");
                    f2.label4.Text = rm.GetString("cqd");
                    f2.label5.Text = rm.GetString("cqe");
                    f2.radioButton1.Text = rm.GetString("aa");
                    f2.radioButton7.Text = rm.GetString("ab");
                    f2.radioButton12.Text = rm.GetString("ac");
                    f2.radioButton15.Text = rm.GetString("ad");
                    f2.radioButton19.Text = rm.GetString("ae");
                    on.c = "2";
                    on.Save();
                }
                else if (on.c == "2")
                {
                    ResourceManager rm = new ResourceManager("online_exam.properties.resource1", Assembly.GetExecutingAssembly()); 
                   
                    f2.label1.Text = rm.GetString("cqf");
                    f2.label2.Text = rm.GetString("cqg");
                    f2.label3.Text = rm.GetString("cqh");
                    f2.label4.Text = rm.GetString("cqi");
                    f2.label5.Text = rm.GetString("cqj");
                    
                    f2.radioButton1.Text = rm.GetString("af");
                    f2.radioButton7.Text = rm.GetString("ag");
                    f2.radioButton12.Text = rm.GetString("ah");
                    f2.radioButton15.Text = rm.GetString("ai");
                    f2.radioButton19.Text = rm.GetString("aj");
                   
                    on.c = "3";
                    on.Save();
                }
                else if (on.c == "3")
                {
                    ResourceManager rm = new ResourceManager("online_exam.properties.resource1", Assembly.GetExecutingAssembly());
                    f2.label1.Text = rm.GetString("cqk");
                    f2.label2.Text = rm.GetString("cql");
                    f2.label3.Text = rm.GetString("cqm");
                    f2.label4.Text = rm.GetString("cqn");
                    f2.label5.Text = rm.GetString("cqo");
                    
                    f2.radioButton1.Text = rm.GetString("ak");
                    f2.radioButton7.Text = rm.GetString("al");
                    f2.radioButton12.Text = rm.GetString("am");
                    f2.radioButton15.Text = rm.GetString("an");
                    f2.radioButton19.Text = rm.GetString("ao");
                   
                    on.c = "1";
                    on.Save();
                }
                    f2.checkBox1.Checked = true;
                    f2.checkBox2.Checked = true;
                    f2.checkBox3.Checked = true;
                    f2.Show();

                }
           else if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == false)
            {
                if (on.c == "1")
                {
                    ResourceManager rm = new ResourceManager("online_exam.properties.resource1", Assembly.GetExecutingAssembly());
                    f2.label1.Text = rm.GetString("cqa");
                    f2.label2.Text = rm.GetString("cqb");
                    f2.label3.Text = rm.GetString("cqc");
                    f2.label4.Text = rm.GetString("cqd");
                    f2.label5.Text = rm.GetString("cqe");
                    f2.radioButton1.Text = rm.GetString("aa");
                    f2.radioButton7.Text = rm.GetString("ab");
                    f2.radioButton12.Text = rm.GetString("ac");
                    f2.radioButton15.Text = rm.GetString("ad");
                    f2.radioButton19.Text = rm.GetString("ae");
                    on.c = "2";
                    on.Save();
                }
                else if (on.c == "2")
                {
                    ResourceManager rm = new ResourceManager("online_exam.properties.resource1", Assembly.GetExecutingAssembly());

                    f2.label1.Text = rm.GetString("cqf");
                    f2.label2.Text = rm.GetString("cqg");
                    f2.label3.Text = rm.GetString("cqh");
                    f2.label4.Text = rm.GetString("cqi");
                    f2.label5.Text = rm.GetString("cqj");

                    f2.radioButton1.Text = rm.GetString("af");
                    f2.radioButton7.Text = rm.GetString("ag");
                    f2.radioButton12.Text = rm.GetString("ah");
                    f2.radioButton15.Text = rm.GetString("ai");
                    f2.radioButton19.Text = rm.GetString("aj");

                    on.c = "3";
                    on.Save();
                }
                else if (on.c == "3")
                {
                    ResourceManager rm = new ResourceManager("online_exam.properties.resource1", Assembly.GetExecutingAssembly());
                    f2.label1.Text = rm.GetString("cqk");
                    f2.label2.Text = rm.GetString("cql");
                    f2.label3.Text = rm.GetString("cqm");
                    f2.label4.Text = rm.GetString("cqn");
                    f2.label5.Text = rm.GetString("cqo");

                    f2.radioButton1.Text = rm.GetString("ak");
                    f2.radioButton7.Text = rm.GetString("al");
                    f2.radioButton12.Text = rm.GetString("am");
                    f2.radioButton15.Text = rm.GetString("an");
                    f2.radioButton19.Text = rm.GetString("ao");

                    on.c = "1";
                    on.Save();
                }
               /* ResourceManager rm1 = new ResourceManager("online_exam.Properties.Resources", Assembly.GetExecutingAssembly());
                if (on.cpp == "1")
                {
                    f3.label1.Text = rm1.GetString("qa");
                    f3.label2.Text = rm1.GetString("qb");
                    f3.label3.Text = rm1.GetString("qc");
                    f3.label4.Text = rm1.GetString("qd");
                    f3.label5.Text = rm1.GetString("qe");
                    f3.radioButton3.Text = rm1.GetString("aa");
                    f3.radioButton6.Text = rm1.GetString("ab");
                    f3.radioButton11.Text = rm1.GetString("ac");
                    f3.radioButton16.Text = rm1.GetString("ad");
                    f3.radioButton20.Text = rm1.GetString("ae");
                    on.cpp = "2";
                    on.Save();
                    f2.checkBox1.Checked = true;
                    f2.checkBox2.Checked = true;
                    f2.checkBox3.Checked = false;
                    f2.Show();
                }
               else if (on.cpp == "2")
                {
                    f3.label1.Text = rm1.GetString("qf");
                    f3.label2.Text = rm1.GetString("qg");
                    f3.label3.Text = rm1.GetString("qh");
                    f3.label4.Text = rm1.GetString("qi");
                    f3.label5.Text = rm1.GetString("qj");
                    f3.radioButton3.Text = rm1.GetString("af");
                    f3.radioButton6.Text = rm1.GetString("ag");
                    f3.radioButton11.Text = rm1.GetString("ah");
                    f3.radioButton16.Text = rm1.GetString("ai");
                    f3.radioButton20.Text = rm1.GetString("aj");
                    on.cpp = "3";
                    on.Save();
                    f2.checkBox1.Checked = true;
                    f2.checkBox2.Checked = true;
                    f2.checkBox3.Checked = false;
                    f2.Show();

                   
                }
                else if(on.cpp == "3")
                {
                    f3.label1.Text = rm1.GetString("qk");
                    f3.label2.Text = rm1.GetString("ql");
                    f3.label3.Text = rm1.GetString("qm");
                    f3.label4.Text = rm1.GetString("qn");
                    f3.label5.Text = rm1.GetString("qo");
                    f3.radioButton3.Text = rm1.GetString("ak");
                    f3.radioButton6.Text = rm1.GetString("al");
                    f3.radioButton11.Text = rm1.GetString("am");
                    f3.radioButton16.Text = rm1.GetString("an");
                    f3.radioButton20.Text = rm1.GetString("ao");
                    on.cpp = "1";
                    on.Save();*/
                    f2.checkBox1.Checked = true;
                    f2.checkBox2.Checked = true;
                    f2.checkBox3.Checked = false;
                    f2.Show();
                
            }

           else if (checkBox1.Checked == true && checkBox2.Checked == false && checkBox3.Checked == false)
            {
                if (on.c == "1")
                {
                    ResourceManager rm = new ResourceManager("online_exam.properties.resource1", Assembly.GetExecutingAssembly());
                    f2.label1.Text = rm.GetString("cqa");
                    f2.label2.Text = rm.GetString("cqb");
                    f2.label3.Text = rm.GetString("cqc");
                    f2.label4.Text = rm.GetString("cqd");
                    f2.label5.Text = rm.GetString("cqe");
                    f2.radioButton1.Text = rm.GetString("aa");
                    f2.radioButton7.Text = rm.GetString("ab");
                    f2.radioButton12.Text = rm.GetString("ac");
                    f2.radioButton15.Text = rm.GetString("ad");
                    f2.radioButton19.Text = rm.GetString("ae");
                    on.c = "2";
                    on.Save();
                }
                else if (on.c == "2")
                {
                    ResourceManager rm = new ResourceManager("online_exam.properties.resource1", Assembly.GetExecutingAssembly());

                    f2.label1.Text = rm.GetString("cqf");
                    f2.label2.Text = rm.GetString("cqg");
                    f2.label3.Text = rm.GetString("cqh");
                    f2.label4.Text = rm.GetString("cqi");
                    f2.label5.Text = rm.GetString("cqj");

                    f2.radioButton1.Text = rm.GetString("af");
                    f2.radioButton7.Text = rm.GetString("ag");
                    f2.radioButton12.Text = rm.GetString("ah");
                    f2.radioButton15.Text = rm.GetString("ai");
                    f2.radioButton19.Text = rm.GetString("aj");

                    on.c = "3";
                    on.Save();
                }
                else if (on.c == "3")
                {
                    ResourceManager rm = new ResourceManager("online_exam.properties.resource1", Assembly.GetExecutingAssembly());
                    f2.label1.Text = rm.GetString("cqk");
                    f2.label2.Text = rm.GetString("cql");
                    f2.label3.Text = rm.GetString("cqm");
                    f2.label4.Text = rm.GetString("cqn");
                    f2.label5.Text = rm.GetString("cqo");

                    f2.radioButton1.Text = rm.GetString("ak");
                    f2.radioButton7.Text = rm.GetString("al");
                    f2.radioButton12.Text = rm.GetString("am");
                    f2.radioButton15.Text = rm.GetString("an");
                    f2.radioButton19.Text = rm.GetString("ao");

                    on.c = "1";
                    on.Save();

                }

                    f2.checkBox1.Checked = true;
                    f2.checkBox2.Checked = false;
                    f2.checkBox3.Checked = false;
                    f2.Show();
                
            }

            else if (checkBox1.Checked == false && checkBox2.Checked == false && checkBox3.Checked == true)
            {
                if (on.c == "1")
                {
                    f4.label1.Text = rm2.GetString("na");
                    f4.label2.Text = rm2.GetString("nb");
                    f4.label3.Text = rm2.GetString("nc");
                    f4.label4.Text = rm2.GetString("nd");
                    f4.label5.Text = rm2.GetString("ne");

                    f4.radioButton1.Text = rm2.GetString("aa");
                    f4.radioButton7.Text = rm2.GetString("ab");
                    f4.radioButton10.Text = rm2.GetString("ac");
                    f4.radioButton13.Text = rm2.GetString("ad");
                    f4.radioButton19.Text = rm2.GetString("ae");
                    on.c = "2";
                    on.Save();
                    f4.Show();
                }
                else if (on.c == "2")
                {
                    f4.label1.Text = rm2.GetString("nf");
                    f4.label2.Text = rm2.GetString("ng");
                    f4.label3.Text = rm2.GetString("nh");
                    f4.label4.Text = rm2.GetString("ni");
                    f4.label5.Text = rm2.GetString("nj");

                    f4.radioButton1.Text = rm2.GetString("af");
                    f4.radioButton7.Text = rm2.GetString("ag");
                    f4.radioButton10.Text = rm2.GetString("ah");
                    f4.radioButton13.Text = rm2.GetString("ai");
                    f4.radioButton19.Text = rm2.GetString("aj");
                    on.c = "3";
                    on.Save();
                    f4.Show();
                }
                else if (on.c == "3")
                {
                    f4.label1.Text = rm2.GetString("nk");
                    f4.label2.Text = rm2.GetString("nl");
                    f4.label3.Text = rm2.GetString("nm");
                    f4.label4.Text = rm2.GetString("nn");
                    f4.label5.Text = rm2.GetString("no");

                    f4.radioButton1.Text = rm2.GetString("ak");
                    f4.radioButton7.Text = rm2.GetString("al");
                    f4.radioButton10.Text = rm2.GetString("am");
                    f4.radioButton13.Text = rm2.GetString("an");
                    f4.radioButton19.Text = rm2.GetString("ao");
                    on.c = "1";
                    on.Save();
                }
                    f4.checkBox1.Checked = false;
                    f4.checkBox2.Checked = false;
                    f4.checkBox3.Checked = true;
                    f4.Show();

                

            }
                else if (checkBox1.Checked == false && checkBox2.Checked == true && checkBox3.Checked == false)
                {
                   
                    if (on.cpp == "1")
                    {
                        f3.label1.Text = rm1.GetString("qa");
                        f3.label2.Text = rm1.GetString("qb");
                        f3.label3.Text = rm1.GetString("qc");
                        f3.label4.Text = rm1.GetString("qd");
                        f3.label5.Text = rm1.GetString("qe");
                        f3.radioButton3.Text = rm1.GetString("aa");
                        f3.radioButton6.Text = rm1.GetString("ab");
                        f3.radioButton11.Text = rm1.GetString("ac");
                        f3.radioButton16.Text = rm1.GetString("ad");
                        f3.radioButton20.Text = rm1.GetString("ae");
                        on.cpp = "2";
                        on.Save();
                    }
                    else if (on.cpp == "2")
                    {
                        f3.label1.Text = rm1.GetString("qf");
                        f3.label2.Text = rm1.GetString("qg");
                        f3.label3.Text = rm1.GetString("qh");
                        f3.label4.Text = rm1.GetString("qi");
                        f3.label5.Text = rm1.GetString("qj");
                        f3.radioButton3.Text = rm1.GetString("af");
                        f3.radioButton6.Text = rm1.GetString("ag");
                        f3.radioButton11.Text = rm1.GetString("ah");
                        f3.radioButton16.Text = rm1.GetString("ai");
                        f3.radioButton20.Text = rm1.GetString("aj");
                        on.cpp = "3";
                        on.Save();


                    }
                    else if (on.cpp == "3")
                    {
                        f3.label1.Text = rm1.GetString("qk");
                        f3.label2.Text = rm1.GetString("ql");
                        f3.label3.Text = rm1.GetString("qm");
                        f3.label4.Text = rm1.GetString("qn");
                        f3.label5.Text = rm1.GetString("qo");
                        f3.radioButton3.Text = rm1.GetString("ak");
                        f3.radioButton6.Text = rm1.GetString("al");
                        f3.radioButton11.Text = rm1.GetString("am");
                        f3.radioButton16.Text = rm1.GetString("an");
                        f3.radioButton20.Text = rm1.GetString("ao");
                        on.cpp = "1";
                        on.Save();
                    }


                    f3.checkBox1.Checked = false;
                    f3.checkBox2.Checked = true;
                    f3.checkBox3.Checked = false;
                    f3.Show();

                }
            else if (checkBox1.Checked == false && checkBox2.Checked == true && checkBox3.Checked == true)
            {
                /* if (on.c == "1")
                 {
                     ResourceManager rm = new ResourceManager("online_exam.properties.resource1", Assembly.GetExecutingAssembly());
                     f2.label1.Text = rm.GetString("cqa");
                     f2.label2.Text = rm.GetString("cqb");
                     f2.label3.Text = rm.GetString("cqc");
                     f2.label4.Text = rm.GetString("cqd");
                     f2.label5.Text = rm.GetString("cqe");
                     f2.radioButton1.Text = rm.GetString("aa");
                     f2.radioButton7.Text = rm.GetString("ab");
                     f2.radioButton12.Text = rm.GetString("ac");
                     f2.radioButton15.Text = rm.GetString("ad");
                     f2.radioButton19.Text = rm.GetString("ae");
                     on.c = "2";
                     on.Save();
                 }
                 else if (on.c == "2")
                 {
                     ResourceManager rm = new ResourceManager("online_exam.properties.resource1", Assembly.GetExecutingAssembly());

                     f2.label1.Text = rm.GetString("cqf");
                     f2.label2.Text = rm.GetString("cqg");
                     f2.label3.Text = rm.GetString("cqh");
                     f2.label4.Text = rm.GetString("cqi");
                     f2.label5.Text = rm.GetString("cqj");

                     f2.radioButton1.Text = rm.GetString("af");
                     f2.radioButton7.Text = rm.GetString("ag");
                     f2.radioButton12.Text = rm.GetString("ah");
                     f2.radioButton15.Text = rm.GetString("ai");
                     f2.radioButton19.Text = rm.GetString("aj");

                     on.c = "3";
                     on.Save();
                 }
                 else if (on.c == "3")
                 {
                     ResourceManager rm = new ResourceManager("online_exam.properties.resource1", Assembly.GetExecutingAssembly());
                     f2.label1.Text = rm.GetString("cqk");
                     f2.label2.Text = rm.GetString("cql");
                     f2.label3.Text = rm.GetString("cqm");
                     f2.label4.Text = rm.GetString("cqn");
                     f2.label5.Text = rm.GetString("cqo");

                     f2.radioButton1.Text = rm.GetString("ak");
                     f2.radioButton7.Text = rm.GetString("al");
                     f2.radioButton12.Text = rm.GetString("am");
                     f2.radioButton15.Text = rm.GetString("an");
                     f2.radioButton19.Text = rm.GetString("ao");

                     on.c = "1";
                     on.Save();
                 }

                 f3.checkBox1.Checked = false;
                 f3.checkBox2.Checked = true;
                 f3.checkBox3.Checked = true;
                 f3.Show();*/
                //}
                if (on.cpp == "1")
                {
                    f3.label1.Text = rm1.GetString("qa");
                    f3.label2.Text = rm1.GetString("qb");
                    f3.label3.Text = rm1.GetString("qc");
                    f3.label4.Text = rm1.GetString("qd");
                    f3.label5.Text = rm1.GetString("qe");
                    f3.radioButton3.Text = rm1.GetString("aa");
                    f3.radioButton6.Text = rm1.GetString("ab");
                    f3.radioButton11.Text = rm1.GetString("ac");
                    f3.radioButton16.Text = rm1.GetString("ad");
                    f3.radioButton20.Text = rm1.GetString("ae");
                    on.cpp = "2";
                    on.Save();
                }
                else if (on.cpp == "2")
                {
                    f3.label1.Text = rm1.GetString("qf");
                    f3.label2.Text = rm1.GetString("qg");
                    f3.label3.Text = rm1.GetString("qh");
                    f3.label4.Text = rm1.GetString("qi");
                    f3.label5.Text = rm1.GetString("qj");
                    f3.radioButton3.Text = rm1.GetString("af");
                    f3.radioButton6.Text = rm1.GetString("ag");
                    f3.radioButton11.Text = rm1.GetString("ah");
                    f3.radioButton16.Text = rm1.GetString("ai");
                    f3.radioButton20.Text = rm1.GetString("aj");
                    on.cpp = "3";
                    on.Save();


                }
                else if (on.cpp == "3")
                {
                    f3.label1.Text = rm1.GetString("qk");
                    f3.label2.Text = rm1.GetString("ql");
                    f3.label3.Text = rm1.GetString("qm");
                    f3.label4.Text = rm1.GetString("qn");
                    f3.label5.Text = rm1.GetString("qo");
                    f3.radioButton3.Text = rm1.GetString("ak");
                    f3.radioButton6.Text = rm1.GetString("al");
                    f3.radioButton11.Text = rm1.GetString("am");
                    f3.radioButton16.Text = rm1.GetString("an");
                    f3.radioButton20.Text = rm1.GetString("ao");
                    on.cpp = "1";
                    on.Save();
                }
                f3.checkBox1.Checked= false;
                f3.checkBox2.Checked = true;
                f3.checkBox3.Checked = true;
                f3.Show();

            }

            else if (checkBox1.Checked == true && checkBox2.Checked == false && checkBox3.Checked == true)
            {
                if (on.c == "1")
                {
                    ResourceManager rm = new ResourceManager("online_exam.properties.resource1", Assembly.GetExecutingAssembly());
                    f2.label1.Text = rm.GetString("cqa");
                    f2.label2.Text = rm.GetString("cqb");
                    f2.label3.Text = rm.GetString("cqc");
                    f2.label4.Text = rm.GetString("cqd");
                    f2.label5.Text = rm.GetString("cqe");
                    f2.radioButton1.Text = rm.GetString("aa");
                    f2.radioButton7.Text = rm.GetString("ab");
                    f2.radioButton12.Text = rm.GetString("ac");
                    f2.radioButton15.Text = rm.GetString("ad");
                    f2.radioButton19.Text = rm.GetString("ae");
                    on.c = "2";
                    on.Save();
                }
                else if (on.c == "2")
                {
                    ResourceManager rm = new ResourceManager("online_exam.properties.resource1", Assembly.GetExecutingAssembly());

                    f2.label1.Text = rm.GetString("cqf");
                    f2.label2.Text = rm.GetString("cqg");
                    f2.label3.Text = rm.GetString("cqh");
                    f2.label4.Text = rm.GetString("cqi");
                    f2.label5.Text = rm.GetString("cqj");

                    f2.radioButton1.Text = rm.GetString("af");
                    f2.radioButton7.Text = rm.GetString("ag");
                    f2.radioButton12.Text = rm.GetString("ah");
                    f2.radioButton15.Text = rm.GetString("ai");
                    f2.radioButton19.Text = rm.GetString("aj");

                    on.c = "3";
                    on.Save();
                }
                else if (on.c == "3")
                {
                    ResourceManager rm = new ResourceManager("online_exam.properties.resource1", Assembly.GetExecutingAssembly());
                    f2.label1.Text = rm.GetString("cqk");
                    f2.label2.Text = rm.GetString("cql");
                    f2.label3.Text = rm.GetString("cqm");
                    f2.label4.Text = rm.GetString("cqn");
                    f2.label5.Text = rm.GetString("cqo");

                    f2.radioButton1.Text = rm.GetString("ak");
                    f2.radioButton7.Text = rm.GetString("al");
                    f2.radioButton12.Text = rm.GetString("am");
                    f2.radioButton15.Text = rm.GetString("an");
                    f2.radioButton19.Text = rm.GetString("ao");

                    on.c = "1";
                    on.Save();
                }

                f2.checkBox1.Checked = true;
                f2.checkBox2.Checked = false;
                f2.checkBox3.Checked = true;
                f2.Show();
            }
            }

                /* else if (checkBox1.Checked == false && checkBox2.Checked == true && checkBox3.Checked == true)
                 {

                     f2.checkBox1.Checked =false;
                     f2.checkBox2.Checked = true;
                     f2.checkBox3.Checked = true;
                     f3.Show();

                 }*/




            
        }
    }


