﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Resources;
using System.Reflection;

namespace online_exam
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            Form2 f2 = new Form2();
            Form3 f3 = new Form3();
            Form4 f4 = new Form4();
            Form5 f5 = new Form5();
             Properties.Settings on = new Properties.Settings();
             
             
                 if (radioButton1.Checked == true)
                 {
                     f5.label13.BackColor = Color.Green;
                 }
                 else
                 {
                     f5.label13.BackColor = Color.Red;
                 }
                 if (radioButton7.Checked == true)
                 {
                     f5.label14.BackColor = Color.Green;
                 }
                 else
                 {
                     f5.label14.BackColor = Color.Red;
                 }
                 if (radioButton10.Checked == true)
                 {
                     f5.label15.BackColor = Color.Green;
                 }
                 else
                 {
                     f5.label15.BackColor = Color.Red;
                 }
                 if (radioButton13.Checked == true)
                 {
                     f5.label16.BackColor = Color.Green;
                 }
                 else
                 {
                     f5.label16.BackColor = Color.Red;
                 }
                 if (radioButton19.Checked == true)
                 {
                     f5.label17.BackColor = Color.Green;
                 }
                 else
                 {
                     f5.label17.BackColor = Color.Red;
                 }


                 if (checkBox1.Checked == false && checkBox2.Checked == false && checkBox3.Checked == true)
                 {
                     if (on.c == "1")
                     {
                          f5.label8.BackColor = label17.BackColor;
                          f5.label9.BackColor = label18.BackColor;
                          f5.label10.BackColor = label19.BackColor;
                          f5.label11.BackColor = label20.BackColor;
                          f5.label12.BackColor = label21.BackColor;
                         on.c = "2";

                         f5.Show();
                     }
                     else if (on.c == "2")
                     {
                         f5.label8.BackColor = label17.BackColor;
                         f5.label9.BackColor = label18.BackColor;
                         f5.label10.BackColor = label19.BackColor;
                         f5.label11.BackColor = label20.BackColor;
                         f5.label12.BackColor = label21.BackColor;
                         on.c = "3";
                         f5.Show();
                     }
                     else if (on.c == "3")
                     {
                         f5.label8.BackColor = label17.BackColor;
                         f5.label9.BackColor = label18.BackColor;
                         f5.label10.BackColor = label19.BackColor;
                         f5.label11.BackColor = label20.BackColor;
                         f5.label12.BackColor = label21.BackColor;
                         f5.Show();
                         on.c = "1";
                     }

                 }


                 else if (checkBox1.Checked == false && checkBox2.Checked == true && checkBox3.Checked == true)
                 {
                   f5.label8.BackColor = label7.BackColor;
                     f5.label9.BackColor = label8.BackColor;
                     f5.label10.BackColor = label9.BackColor;
                     f5.label11.BackColor = label10.BackColor;
                     f5.label12.BackColor = label11.BackColor;

                    /* f5.label8.BackColor = label12.BackColor;
                     f5.label9.BackColor = label13.BackColor;
                     f5.label10.BackColor = label14.BackColor;
                     f5.label11.BackColor = label15.BackColor;
                     f5.label12.BackColor = label16.BackColor;*/



                     f5.Show();
                 }
                 else if (checkBox1.Checked == true && checkBox2.Checked == false && checkBox3.Checked == true)
                 {
                     f5.label3.BackColor = label7.BackColor;
                     f5.label4.BackColor = label8.BackColor;
                     f5.label5.BackColor = label9.BackColor;
                     f5.label6.BackColor = label10.BackColor;
                     f5.label7.BackColor = label11.BackColor;


                     f5.Show();
                 }
            if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == true)
            {
                f5.label3.BackColor = label12.BackColor;
                f5.label4.BackColor = label13.BackColor;
                f5.label5.BackColor = label14.BackColor;
                f5.label6.BackColor = label15.BackColor;
                f5.label7.BackColor = label16.BackColor;
                f5.label8.BackColor = label7.BackColor;
                f5.label9.BackColor = label8.BackColor;
                f5.label10.BackColor = label9.BackColor;
                f5.label11.BackColor = label10.BackColor;
                f5.label12.BackColor = label11.BackColor;


                f5.Show();
            }

            
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton18_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton19_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton20_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
