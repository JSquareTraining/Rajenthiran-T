﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;

namespace online_exam
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form5 f5 = new Form5();
            Form1 f1 = new Form1();
            Form2 f2 = new Form2();
            Form3 f3 = new Form3();
            Form4 f4 = new Form4();
            Properties.Settings on = new Properties.Settings();
            ResourceManager rm2 = new ResourceManager("online_exam.net", Assembly.GetExecutingAssembly());

            if (radioButton3.Checked == true)
            {

                f5.label8.BackColor = Color.Green;
            }
            else
            {
                f5.label8.BackColor = Color.Red;
            }
            if (radioButton6.Checked == true)
            {
                f5.label9.BackColor = Color.Green;
            }
            else
            {
                f5.label9.BackColor = Color.Red;
            }
            if (radioButton11.Checked == true)
            {
                f5.label10.BackColor = Color.Green;
            }
            else
            {
                f5.label10.BackColor = Color.Red;
            }
            if (radioButton16.Checked == true)
            {
                f5.label11.BackColor = Color.Green;
            }
            else
            {
                f5.label11.BackColor = Color.Red;
            }
            if (radioButton20.Checked == true)
            {
                f5.label12.BackColor = Color.Green;
            }
            else
            {
                f5.label12.BackColor = Color.Red;
            }


            if (checkBox1.Checked == false && checkBox2.Checked == true && checkBox3.Checked == false)
            {
                f3.checkBox1.Checked = false;
                f3.checkBox2.Checked = true;
                f3.checkBox3.Checked = false;
                f5.Show();


            }

            else if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == false)
            {
                f5.label3.BackColor = label7.BackColor;
                f5.label4.BackColor = label8.BackColor;
                f5.label5.BackColor = label9.BackColor;
                f5.label6.BackColor = label10.BackColor;
                f5.label7.BackColor = label11.BackColor;

                f5.Show();
            }
            else if (checkBox1.Checked == true && checkBox2.Checked == false && checkBox3.Checked == false)
            {
                f4.checkBox1.Checked = true;
                f4.checkBox2.Checked = false;
                f4.checkBox3.Checked = false;

                f5.Show();
            }


            if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == true)
            {
                if (on.c == "1")
                {
                    f4.label1.Text = rm2.GetString("na");
                    f4.label2.Text = rm2.GetString("nb");
                    f4.label3.Text = rm2.GetString("nc");
                    f4.label4.Text = rm2.GetString("nd");
                    f4.label5.Text = rm2.GetString("ne");

                    f4.radioButton1.Text = rm2.GetString("aa");
                    f4.radioButton7.Text = rm2.GetString("ab");
                    f4.radioButton10.Text = rm2.GetString("ac");
                    f4.radioButton13.Text = rm2.GetString("ad");
                    f4.radioButton19.Text = rm2.GetString("ae");
                    on.c = "2";
                    on.Save();
                }
                else if (on.c == "2")
                {
                    f4.label1.Text = rm2.GetString("nf");
                    f4.label2.Text = rm2.GetString("ng");
                    f4.label3.Text = rm2.GetString("nh");
                    f4.label4.Text = rm2.GetString("ni");
                    f4.label5.Text = rm2.GetString("nj");

                    f4.radioButton1.Text = rm2.GetString("af");
                    f4.radioButton7.Text = rm2.GetString("ag");
                    f4.radioButton10.Text = rm2.GetString("ah");
                    f4.radioButton13.Text = rm2.GetString("ai");
                    f4.radioButton19.Text = rm2.GetString("aj");
                    on.c = "3";
                    on.Save();
                }
                else if (on.c == "3")
                {
                    f4.label1.Text = rm2.GetString("nk");
                    f4.label2.Text = rm2.GetString("nl");
                    f4.label3.Text = rm2.GetString("nm");
                    f4.label4.Text = rm2.GetString("nn");
                    f4.label5.Text = rm2.GetString("no");

                    f4.radioButton1.Text = rm2.GetString("ak");
                    f4.radioButton7.Text = rm2.GetString("al");
                    f4.radioButton10.Text = rm2.GetString("am");
                    f4.radioButton13.Text = rm2.GetString("an");
                    f4.radioButton19.Text = rm2.GetString("ao");
                    on.c = "1";
                    on.Save();

                
               
            }

                if (radioButton3.Checked == true)
                {

                    f4.label7.BackColor = Color.Green;
                }
                else
                {
                    f4.label7.BackColor = Color.Red;
                }
                if (radioButton6.Checked == true)
                {
                    f4.label8.BackColor = Color.Green;
                }
                else
                {
                    f4.label8.BackColor = Color.Red;
                }
                if (radioButton11.Checked == true)
                {
                    f4.label9.BackColor = Color.Green;
                }
                else
                {
                    f4.label9.BackColor = Color.Red;
                }
                if (radioButton16.Checked == true)
                {
                    f4.label10.BackColor = Color.Green;
                }
                else
                {
                    f4.label10.BackColor = Color.Red;
                }
                if (radioButton20.Checked == true)
                {
                    f4.label11.BackColor = Color.Green;
                }
                else
                {
                    f4.label11.BackColor = Color.Red;
                }

                f4.checkBox1.Checked = true;
                f4.checkBox2.Checked = true;
                f4.checkBox3.Checked = true;
                f4.label12.BackColor = label12.BackColor;
                f4.label13.BackColor = label13.BackColor;
                f4.label14.BackColor = label14.BackColor;
                f4.label15.BackColor = label15.BackColor;
                f4.label16.BackColor = label16.BackColor;



                f4.Show();

            }
            else if (checkBox1.Checked == false && checkBox2.Checked == true && checkBox3.Checked == true)
            {
                if (radioButton3.Checked == true)
                {

                    f4.label7.BackColor = Color.Green;
                }
                else
                {
                    f4.label7.BackColor = Color.Red;
                }
                if (radioButton6.Checked == true)
                {
                    f4.label8.BackColor = Color.Green;
                }
                else
                {
                    f4.label8.BackColor = Color.Red;
                }
                if (radioButton11.Checked == true)
                {
                    f4.label9.BackColor = Color.Green;
                }
                else
                {
                    f4.label9.BackColor = Color.Red;
                }
                if (radioButton16.Checked == true)
                {
                    f4.label10.BackColor = Color.Green;
                }
                else
                {
                    f4.label10.BackColor = Color.Red;
                }
                if (radioButton20.Checked == true)
                {
                    f4.label11.BackColor = Color.Green;
                }
                else
                {
                    f4.label11.BackColor = Color.Red;
                }

                if (on.c == "1")
                {
                    f4.label1.Text = rm2.GetString("na");
                    f4.label2.Text = rm2.GetString("nb");
                    f4.label3.Text = rm2.GetString("nc");
                    f4.label4.Text = rm2.GetString("nd");
                    f4.label5.Text = rm2.GetString("ne");

                    f4.radioButton1.Text = rm2.GetString("aa");
                    f4.radioButton7.Text = rm2.GetString("ab");
                    f4.radioButton10.Text = rm2.GetString("ac");
                    f4.radioButton13.Text = rm2.GetString("ad");
                    f4.radioButton19.Text = rm2.GetString("ae");
                    on.c = "2";
                    on.Save();
                }
                else if (on.c == "2")
                {
                    f4.label1.Text = rm2.GetString("nf");
                    f4.label2.Text = rm2.GetString("ng");
                    f4.label3.Text = rm2.GetString("nh");
                    f4.label4.Text = rm2.GetString("ni");
                    f4.label5.Text = rm2.GetString("nj");

                    f4.radioButton1.Text = rm2.GetString("af");
                    f4.radioButton7.Text = rm2.GetString("ag");
                    f4.radioButton10.Text = rm2.GetString("ah");
                    f4.radioButton13.Text = rm2.GetString("ai");
                    f4.radioButton19.Text = rm2.GetString("aj");
                    on.c = "3";
                    on.Save();
                }
                else if (on.c == "3")
                {
                    f4.label1.Text = rm2.GetString("nk");
                    f4.label2.Text = rm2.GetString("nl");
                    f4.label3.Text = rm2.GetString("nm");
                    f4.label4.Text = rm2.GetString("nn");
                    f4.label5.Text = rm2.GetString("no");

                    f4.radioButton1.Text = rm2.GetString("ak");
                    f4.radioButton7.Text = rm2.GetString("al");
                    f4.radioButton10.Text = rm2.GetString("am");
                    f4.radioButton13.Text = rm2.GetString("an");
                    f4.radioButton19.Text = rm2.GetString("ao");
                    on.c = "1";
                    on.Save();

                }
               /* f4.label7.BackColor = label7.BackColor;
                f4.label8.BackColor = label8.BackColor;
                f4.label9.BackColor = label9.BackColor;
                f4.label10.BackColor = label10.BackColor;
                f4.label11.BackColor = label11.BackColor;*/



                
                
                /* if (radioButton3.Checked == true)
                 {

                     f4.label17.BackColor = Color.Green;
                 }
                 else
                 {
                     f4.label17.BackColor = Color.Red;
                 }
                 if (radioButton6.Checked == true)
                 {
                     f4.label18.BackColor = Color.Green;
                 }
                 else
                 {
                     f4.label18.BackColor = Color.Red;
                 }
                 if (radioButton11.Checked == true)
                 {
                     f4.label19.BackColor = Color.Green;
                 }
                 else
                 {
                     f4.label19.BackColor = Color.Red;
                 }
                 if (radioButton16.Checked == true)
                 {
                     f4.label20.BackColor = Color.Green;
                 }
                 else
                 {
                     f4.label20.BackColor = Color.Red;
                 }
                 if (radioButton20.Checked == true)
                 {
                     f4.label21.BackColor = Color.Green;
                 }
                 else
                 {
                     f4.label21.BackColor = Color.Red;
                 }*/
            
                 f3.checkBox1.Checked = false;
                 f4.checkBox2.Checked = true;
                 f4.checkBox3.Checked = true;
                 f4.Show();

             


            }
        }
    }
}
//}
