﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;

namespace austrologies
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
               //Form3 f3 = new Form3();
        ResourceManager rm = new ResourceManager("austrologies.Properties.Resources", Assembly.GetExecutingAssembly());
        ResourceManager rm1 = new ResourceManager("austrologies.Properties.Resource1", Assembly.GetExecutingAssembly());
        ResourceManager rm2 = new ResourceManager("austrologies.nacha", Assembly.GetExecutingAssembly());
        ResourceManager rm3 = new ResourceManager("austrologies.color", Assembly.GetExecutingAssembly());
       
        private void button1_Click(object sender, EventArgs e)
        {
           
            
            Form2 f2 = new Form2();
            Form3 f3 = new Form3();

            
            f2.name.Text = textBox1.Text;
            if (radioButton1.Checked == true)
            {
                f2.txt_gender.Text = radioButton1.Text;
            }
            else if(radioButton2.Checked==true)
            {
                f2.txt_gender.Text = radioButton2.Text;
            }
            int i = dateTimePicker1.Value.Year;
            int j = DateTime.Now.Year;
            int a = j - i;
            f2.txt_age.Text = a.ToString();
            
            if(a<=18)
            {
                if (comboBox1.Text == "மேஷ ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "  "+ rm.GetString("mesa");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\me1.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\1.jpg");
                }
                else if (comboBox1.Text == "ரிஷப ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "  " + rm.GetString("risa");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\ri.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\2.jpg");
                }
                else if (comboBox1.Text == "மிதுன  ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "   " + rm.GetString("mith");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\mi.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\3.jpg");
                }

                else if (comboBox1.Text == "சிம்ம  ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "   " + rm.GetString("simm");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\si.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\4.jpg");
                }

                else if (comboBox1.Text == "கடக ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "   " + rm.GetString("kada");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\kad.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\5.png");
                }

                else if (comboBox1.Text == "கன்னி ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "   " + rm.GetString("kann");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\ka.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\6.jpg");
                }

                else if (comboBox1.Text == "துலாம்  ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "   " + rm.GetString("thul");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\th.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\7.jpg");
                }

                else if (comboBox1.Text == "விருச்சிக ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "   " + rm.GetString("viru");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\vi.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\8.jpg");
                }

                else if (comboBox1.Text == "தனுசு  ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "   " + rm.GetString("dhan");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\dh.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\9.jpg");
                }
                else if (comboBox1.Text == "மகர ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "   " + rm.GetString("maka");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\ma.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\10.jpg");
                }
                else if (comboBox1.Text == "கும்ப  ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "   " + rm.GetString("kump");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\ku.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\11.jpg");
                }
                else if (comboBox1.Text == "மீன ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "   " + rm.GetString("meen");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\mee.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\12.jpg");
                }
            }
            if (a >= 18)
            {
                if (comboBox1.Text == "மேஷ ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "  "+ rm1.GetString("mesa");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\me1.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\1.jpg");
                }
                else if (comboBox1.Text == "ரிஷப ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "  " + rm1.GetString("risa");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\ri.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\2.jpg");
                }
                else if (comboBox1.Text == "மிதுன  ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "   " + rm1.GetString("mith");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\mi.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\3.jpg");
                }

                else if (comboBox1.Text == "சிம்ம  ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "   " + rm1.GetString("simm");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\si.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\4.jpg");
                }
                    
                else if (comboBox1.Text == "கடக ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "   " + rm1.GetString("kada");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\kad.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\5.jpg");
                }

                else if (comboBox1.Text == "கன்னி ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "   " + rm1.GetString("kann");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\ka.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\6.jpg");
                }

                else if (comboBox1.Text == "துலாம்  ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "   " + rm1.GetString("thul");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\th.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\7.jpg");
                }

                else if (comboBox1.Text == "விருச்சிக ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "   " + rm1.GetString("viru");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\vi.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\8.jpg");
                }

                else if (comboBox1.Text == "தனுசு  ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "   " + rm1.GetString("dhan");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\dh.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\9.jpg");
                }
                else if (comboBox1.Text == "மகர ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "   " + rm1.GetString("maka");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\ma.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\10.jpg");
                }
                else if (comboBox1.Text == "கும்ப  ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "   " + rm1.GetString("kump");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\ku.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\11.jpg");
                }
                else if (comboBox1.Text == "மீன ராசி")
                {
                    f2.richTextBox2.Text = textBox1.Text + "   " + comboBox1.Text + "   " + rm1.GetString("meen");
                    f2.pictureBox1.Image = Image.FromFile(@"D:\net\jj\mee.jpg");
                    f2.pictureBox2.Image = Image.FromFile(@"D:\net\jj\12.jpg");
                }
            }
            if (comboBox2.Text=="அனுச நட்சத்திரம்")
            
            {
                
                f2.richTextBox3.Text=rm2.GetString("anus");
            }
            else if(comboBox2.Text=="அவீட நட்சத்திரம்")
            {
                f2.richTextBox3.Text=rm2.GetString("avit");
            }
             else if(comboBox2.Text=="பரணி நட்சத்திரம்")
            {
                f2.richTextBox3.Text=rm2.GetString("bara");
            }
             else if(comboBox2.Text=="அசுத நட்சத்திரம்")
            {
                f2.richTextBox3.Text=rm2.GetString("asta");
            }
             else if(comboBox2.Text=="முல நட்சத்திரம்")
            {
                f2.richTextBox3.Text=rm2.GetString("mula");
            }

         
        if(comboBox3.Text=="சிவப்பு")
            {
                f2.richTextBox4.Text=rm3.GetString("red");
            }
    else if(comboBox3.Text=="பச்சை")
            {
                f2.richTextBox4.Text=rm3.GetString("gree");
            }
    else if(comboBox3.Text=="மஞ்சள்")
            {
                f2.richTextBox4.Text=rm3.GetString("yell");
            }
    else if(comboBox3.Text=="கருப்பு")
            {
                f2.richTextBox4.Text=rm3.GetString("bloc");
            }
    else if(comboBox3.Text=="நீலம்")
            {
                f2.richTextBox4.Text=rm3.GetString("sky");
            }
    else if(comboBox3.Text=="வெள்ளை")
            {
                f2.richTextBox4.Text=rm3.GetString("whit");
            }
            
        
            
             f2.Show();
    }
         

       private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
}
}
