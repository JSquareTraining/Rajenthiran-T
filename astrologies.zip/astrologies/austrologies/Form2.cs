﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace austrologies
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }


        //Form3 f3 = new Form3();
        Form1 f1 = new Form1();
       
        private void button1_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.pictureBox1.Image = pictureBox1.Image;
            f3.pictureBox2.Image = pictureBox2.Image;
            f3.richTextBox1.Text = this.richTextBox2.Text;
            f3.Show();
         
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.richTextBox1.Text =this. richTextBox3.Text;
            f3.pictureBox2.Image = pictureBox2.Image;
            f3.pictureBox1.Image = pictureBox1.Image;
            f3.Show();
       
        }

        private void button3_Click(object sender, EventArgs e)
        {

            Form3 f3 = new Form3();
            f3.richTextBox1.Text = this.richTextBox4.Text;
            f3.pictureBox1.Image = pictureBox1.Image;
            f3.pictureBox2.Image = pictureBox2.Image;

            f3.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            
            this.Close();
        }
        
        
    }

}
