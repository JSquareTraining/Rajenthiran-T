﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace class_library
{
    public class Class1
    {
        int i = 0;
        public int add(params int[] value)
        {
            foreach (var n in value)
            {
                i = i + n;
            }
            return i;

        }
        public int sub(int a, int b)
        {
            int i = a - b;
            return i;
        }
    }
}
