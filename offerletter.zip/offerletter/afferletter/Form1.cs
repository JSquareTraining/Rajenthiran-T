﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace afferletter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
           
        }
       
        private void button1_Click_1(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();

            string n = f2.rich_affer.Text;
            string na = txt_name.Text;
            string p=txt_possition.Text;
            string d = txt_date.Text;
            string c = txt_company.Text;
            string s = txt_salary.Text;
            string b = txt_place.Text;
            string cc = txt_city.Text;
            f2.rich_affer.Text = f2.rich_affer.Text.Replace("[name]", na.ToString());
            f2.rich_affer.Text = f2.rich_affer.Text.Replace("[possition]", p.ToString());
            f2.rich_affer.Text = f2.rich_affer.Text.Replace("[date]", d.ToString());
            f2.rich_affer.Text = f2.rich_affer.Text.Replace("[companyname]", c.ToString());
            f2.rich_affer.Text = f2.rich_affer.Text.Replace("[rs]",s.ToString());
            f2.rich_affer.Text = f2.rich_affer.Text.Replace("[place]",b.ToString());
           f2.rich_affer.Text = f2.rich_affer.Text.Replace("[city]", cc.ToString());

            f2.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txt_name_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_date_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_possition_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_company_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_place_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_salary_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_city_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
