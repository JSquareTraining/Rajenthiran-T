﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace msg_box
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // MessageBox.Show("register", "msg_box",MessageBoxButtons.YesNoCancel,MessageBoxIcon.Error,MessageBoxDefaultButton.Button2);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        int l = 0;

        private void login_Click(object sender, EventArgs e)
        {
            DialogResult msg = new DialogResult();

            if (username.Text == "raja" && password.Text == "12345")
            {
                msg = MessageBox.Show("your login succuss", "welcome login", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button2);

            }
            else if (msg == DialogResult.No)
            {
                this.Close();
            }
            else if (msg == DialogResult.Cancel)
            {
                MessageBox.Show("cancel");
            }



            else if (username.Text == "raja")
            {
               MessageBox.Show("password is wrong");
            }
            else if (username.Text == "" && password.Text == "")
            {
                MessageBox.Show("insert user name and password");
            }
            else if (username.Text == "")
            {
                MessageBox.Show("insert your username");
            }

            else if (password.Text == "12345")
            {
                MessageBox.Show("user name is wrong");
            }
            else if (password.Text == "")
            {
                MessageBox.Show("insert your password");
            }
            

            else if (username.Text == "raja" && password.Text != "12345")
            {
                l++;
                if (l == 1)
                {
                    MessageBox.Show("user name or password is wrong");
                }
                else if (l == 2)
                {
                    MessageBox.Show("user name or password is wrong");
                }
                else if (l == 3)
                {
                    MessageBox.Show("user name or password is wrong");

                }
                else if (l == 4)
                {
                    this.Close();
                }

            }
            username.Text = "";
            password.Text = "";
        }
    }
}

    
            //else if (username.Text != "raja" && password.Text != "12345")
           // {
              //  l++;
               // if (l == 1)
               // {
                    //MessageBox.Show("user name or password is wrong");
               // }
                //else if (l == 2)
               // {
                //    MessageBox.Show("user name or password is wrong");
                //}
                //else if (l == 3)
                //{
                 //   MessageBox.Show("user name or password is wrong");

               // }
               // else if (l == 4)
               // {
                 //   this.Close();
               // }
           // }
           // }
            
   /*   int i = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            i++;
            
            
                if (i == 1)
                {
                    MessageBox.Show("gshgjs");
                }
                else if (i == 2)
                {
                    MessageBox.Show("6643");
                }
                else
                {
                    this.Close();
                }
             

        }*/
         
    

