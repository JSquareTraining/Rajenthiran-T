﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace text_count
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            int i = 50;
            int s = richTextBox1.Text.Count();
            int n = i - s;
            label1.Text = n.ToString() +"   reminig charecter";
            //int w = Convert.ToInt32(label1.Text);

            if (n <= 10)
            {
                label1.ForeColor = Color.Red;
            }
            else
            {
                label1.ForeColor = Color.Green;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int i = textBox1.Text.Length;
            string s = textBox1.Text;
            //int j = i - 1;
            for (int a = i-1; -1 < i; a--)
            {
                
                MessageBox.Show(s[a].ToString());
                i--;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text.ToUpper().Remove(1) + textBox1.Text.Substring(1);
            //string s = textBox1.Text;
            //string l = s.Substring(1);
            //string a = s.Remove(1);
            //string m = a.ToUpper();
            //string n = m + l;
          
            //MessageBox.Show(n.ToString());
        }
    }
}
