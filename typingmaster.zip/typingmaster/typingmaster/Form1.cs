﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace typingmaster
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer3.Start(); 
            
            
            
        }
        Point p = new Point();
        Point p1 = new Point();
        Point p2 = new Point();
        Point p3 = new Point();
        Point p4 = new Point();
        Point p5 = new Point();
        Point p6= new Point();
       // Point po = new Point();
        private void timer1_Tick(object sender, EventArgs e)
        
        {
           
           
            if (p.Y >- 200)
            {
                p.X += 0;
                p.Y += -10;
                
                la.Location = p;
            }
            else
            {
                p.X = 400;
                p.Y = 700;
                la.Visible = true;
            }
            if (p.Y == 10 && la.Visible==true)
            {
                textBox2.Text += la.Text;
            }
            
            if (p1.Y > -200)
            {
                p1.X += 0;
                p1.Y += -10;

                lb.Location = p1;
            }
            else
            {
                p1.X =10;
                p1.Y = 600;
                lb.Visible = true;
            }
            if (p1.Y == 10 && lb.Visible==true)
            {
                textBox2.Text += lb.Text;
            }
            if (p1.Y > -200)
            {
                p1.X += 0;
                p1.Y += -10;

                lc.Location = p1;
            }
            else
            {
                p1.X = 110;
                p1.Y = 800;
                lc.Visible = true;
            }
            if (p1.Y == 10 && lc.Visible==true)
            {
                textBox2.Text += lc.Text;
            }
            if (p2.Y > -200)
            {
                p2.X += 0;
                p2.Y += -10;

                ld.Location = p2;
            }
            else
            {
                p2.X = 700;
                p2.Y = 900;
                ld.Visible = true;
            }
            if (p2.Y == 10 && ld.Visible==true)
            {
                textBox2.Text += ld.Text;
            }
            if (p3.Y > -200)
            {
                p3.X += 0;
                p3.Y += -10;

                le.Location = p3;
            }
            else
            {
                p3.X = 500;
                p3.Y = 650;
                le.Visible = true;
            }
            if (p3.Y == 10 && le.Visible == true)
            {
                textBox2.Text += le.Text;
            }
            if (p4.Y > -200)
            {
                p4.X += 0;
                p4.Y += -10;

                lf.Location = p4;
            }
            else
            {
                p4.X = 300;
                p4.Y = 600;
                lf.Visible = true;
            }
            if (p4.Y == 10 && lf.Visible == true)
            {
                textBox2.Text += lf.Text;
            }
            if (p5.Y > -200)
            {
                p5.X += 0;
                p5.Y += -10;

                lg.Location = p5;
            }
            else
            {
                p5.X = 550;
                p5.Y = 900;
                lg.Visible = true;
            }
            if (p5.Y == 10 && lg.Visible == true)
            {
                textBox2.Text += lg.Text;
            }
            if (p6.Y > -200)
            {
                p6.X += 0;
                p6.Y += -10;

                lh.Location = p6;
            }
            else
            {
                p6.X = 110;
                p6.Y = 1000;
                lh.Visible = true;
            }
            if (p6.Y == 10 && lh.Visible==true)
            {
                textBox2.Text += lh.Text;
            }
            
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //timer1.Stop();
        }

        private void label1_Click(object sender, EventArgs e)
        {
           
           /* if (progressBar1.Value < 1000)
            {
                progressBar1.Value += 100;
            }*/
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            

              
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
        int l = 0;
        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            timer1.Start();
            timer2.Start();
            if (la.Text == "a" && textBox1.Text=="a")
            {
                l++;
                la.Visible = false;
                textBox1.Text = "";
              
               
            }
            if (lb.Text == "b" && textBox1.Text == "b")
            {
                l++;
                lb.Visible = false;
                textBox1.Text = "";
                

            }
            if (lc.Text == "c" && textBox1.Text == "c")
            {
                l++;
                lc.Visible = false;
                textBox1.Text = "";
               // textBox3.Text += lc;

            }
            if (ld.Text == "d" && textBox1.Text == "d")
            {
                l++;
                ld.Visible = false;
                textBox1.Text = "";

            }
            if (le.Text == "e" && textBox1.Text == "e")
            {
                l++;
                le.Visible = false;
                textBox1.Text = "";

            }
            if (lf.Text == "f" && textBox1.Text == "f")
            {
                l++;
                lf.Visible = false;
                textBox1.Text = "";

            }
            if (lg.Text == "g" && textBox1.Text == "g")
            {
                l++;
                lg.Visible = false;
                textBox1.Text = "";

            }
            if (lh.Text == "h" && textBox1.Text == "h")
            {
                l++;
                lh.Visible = false;
                textBox1.Text = "";

            }
            if ( textBox1.Text == "i")
            {
                textBox1.Text = "";
            }
            if (textBox1.Text == "j")
            {
                textBox1.Text = "";
            }
            if ( textBox1.Text == "k")
            {
                textBox1.Text = "";
            }
            if ( textBox1.Text == "l")
            {
                textBox1.Text = "";
            }
            if ( textBox1.Text == "m")
            {
                textBox1.Text = "";
            }
            if (textBox1.Text == "n")
            {
                textBox1.Text = "";
            }
            if (textBox1.Text == "o")
            {
                textBox1.Text = "";
            }
            if (textBox1.Text == "p")
            {
                textBox1.Text = "";
            }
            if ( textBox1.Text == "q")
            {
                textBox1.Text = "";
            }
            if (textBox1.Text == "r")
            {
                textBox1.Text = "";
            }
            if (textBox1.Text == "s")
            {
                textBox1.Text = "";
            }
            if (textBox1.Text == "t")
            {
                textBox1.Text = "";
            }
            if (textBox1.Text == "u")
            {
                textBox1.Text = "";
            }
            if (textBox1.Text == "v")
            {
                textBox1.Text = "";
            }
            if (textBox1.Text == "w")
            {
                textBox1.Text = "";
            }
            if (textBox1.Text == "x")
            {
                textBox1.Text = "";
            }
            if (textBox1.Text == "y")
            {
                textBox1.Text = "";
            }
            if (textBox1.Text == "z")
            {
                textBox1.Text = "";
            }
            textBox3.Text = l.ToString();
        //    int n = textBox1.Text.Length;
        //    textBox3.Text = n.ToString();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
                int i = textBox2.Text.Length;
            if (i <= 20)
            {

            }
            else
            {
                timer1.Stop();
                timer2.Stop();
                MessageBox.Show("you have lost game");
            }
        }
        int k = 60;
        private void timer2_Tick(object sender, EventArgs e)
        {
           
            if (k > 0)
            {
                k--;
                label1.Text = k.ToString();
            }
            else
            {
                timer2.Stop();
                timer1.Stop();
                MessageBox.Show("you are lost");

            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (textBox3.Text == "40")
            {
                timer1.Stop();
                timer2.Stop();
                MessageBox.Show("you are win ");
               
            }
        }
        Point po = new Point();
        Point po1 = new Point();

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (po.X < 10500)
            {
                po.X += 10;
                po.Y += 0;

                ovalShape1.Location = po;
            }
            else
            {
                po.X = 0;
                po.Y = 28;
            }
            if (po1.Y < 900)
            {
                po1.X += 5;
                po1.Y += 1;

                ovalShape2.Location = po1;
            }
            else
            {
                po1.X = 5;
                po1.Y = 90;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            k = 60;
            l = 0;
            textBox3.Text = "0";
            timer1.Start();
            timer2.Start();
            timer3.Start();
           
        }

        private void label3_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            timer2.Stop();
            timer3.Stop();
           
        }

        
    }
}
