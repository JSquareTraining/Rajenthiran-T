﻿namespace typingmaster
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.la = new System.Windows.Forms.Label();
            this.lg = new System.Windows.Forms.Label();
            this.lf = new System.Windows.Forms.Label();
            this.le = new System.Windows.Forms.Label();
            this.ld = new System.Windows.Forms.Label();
            this.lc = new System.Windows.Forms.Label();
            this.lb = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lh = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.ovalShape2 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ovalShape1 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 2;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // la
            // 
            this.la.BackColor = System.Drawing.Color.Transparent;
            this.la.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.la.ForeColor = System.Drawing.Color.Red;
            this.la.Location = new System.Drawing.Point(181, 484);
            this.la.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.la.Name = "la";
            this.la.Size = new System.Drawing.Size(30, 32);
            this.la.TabIndex = 10;
            this.la.Tag = "1";
            this.la.Text = "a";
            // 
            // lg
            // 
            this.lg.BackColor = System.Drawing.Color.Transparent;
            this.lg.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lg.ForeColor = System.Drawing.Color.Red;
            this.lg.Location = new System.Drawing.Point(753, 468);
            this.lg.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lg.Name = "lg";
            this.lg.Size = new System.Drawing.Size(30, 32);
            this.lg.TabIndex = 11;
            this.lg.Text = "g";
            // 
            // lf
            // 
            this.lf.BackColor = System.Drawing.Color.Transparent;
            this.lf.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lf.ForeColor = System.Drawing.Color.Red;
            this.lf.Location = new System.Drawing.Point(678, 484);
            this.lf.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lf.Name = "lf";
            this.lf.Size = new System.Drawing.Size(30, 32);
            this.lf.TabIndex = 12;
            this.lf.Text = "f";
            // 
            // le
            // 
            this.le.BackColor = System.Drawing.Color.Transparent;
            this.le.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.le.ForeColor = System.Drawing.Color.Red;
            this.le.Location = new System.Drawing.Point(602, 475);
            this.le.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.le.Name = "le";
            this.le.Size = new System.Drawing.Size(30, 32);
            this.le.TabIndex = 13;
            this.le.Text = "e";
            // 
            // ld
            // 
            this.ld.BackColor = System.Drawing.Color.Transparent;
            this.ld.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ld.ForeColor = System.Drawing.Color.Red;
            this.ld.Location = new System.Drawing.Point(493, 475);
            this.ld.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ld.Name = "ld";
            this.ld.Size = new System.Drawing.Size(30, 32);
            this.ld.TabIndex = 14;
            this.ld.Text = "d";
            // 
            // lc
            // 
            this.lc.BackColor = System.Drawing.Color.Transparent;
            this.lc.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lc.ForeColor = System.Drawing.Color.Red;
            this.lc.Location = new System.Drawing.Point(382, 475);
            this.lc.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lc.Name = "lc";
            this.lc.Size = new System.Drawing.Size(30, 32);
            this.lc.TabIndex = 15;
            this.lc.Text = "c";
            // 
            // lb
            // 
            this.lb.BackColor = System.Drawing.Color.Transparent;
            this.lb.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb.ForeColor = System.Drawing.Color.Red;
            this.lb.Location = new System.Drawing.Point(266, 475);
            this.lb.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb.Name = "lb";
            this.lb.Size = new System.Drawing.Size(30, 32);
            this.lb.TabIndex = 16;
            this.lb.Text = "b";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(318, 462);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(61, 28);
            this.textBox1.TabIndex = 17;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(416, 362);
            this.textBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(200, 20);
            this.textBox2.TabIndex = 18;
            this.textBox2.Visible = false;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // lh
            // 
            this.lh.BackColor = System.Drawing.Color.Transparent;
            this.lh.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lh.ForeColor = System.Drawing.Color.Red;
            this.lh.Location = new System.Drawing.Point(868, 468);
            this.lh.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lh.Name = "lh";
            this.lh.Size = new System.Drawing.Size(30, 32);
            this.lh.TabIndex = 19;
            this.lh.Tag = "1";
            this.lh.Text = "h";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(893, 172);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 41);
            this.label1.TabIndex = 20;
            this.label1.Text = "60";
            // 
            // timer2
            // 
            this.timer2.Interval = 1000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.SystemColors.InfoText;
            this.textBox3.Font = new System.Drawing.Font("Goudy Stout", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.textBox3.Location = new System.Drawing.Point(898, 236);
            this.textBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(52, 45);
            this.textBox3.TabIndex = 21;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.ovalShape2,
            this.ovalShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(972, 507);
            this.shapeContainer1.TabIndex = 22;
            this.shapeContainer1.TabStop = false;
            // 
            // ovalShape2
            // 
            this.ovalShape2.BackgroundImage = global::typingmaster.Properties.Resources.images;
            this.ovalShape2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ovalShape2.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dot;
            this.ovalShape2.Location = new System.Drawing.Point(943, 291);
            this.ovalShape2.Name = "ovalShape2";
            this.ovalShape2.Size = new System.Drawing.Size(158, 120);
            // 
            // ovalShape1
            // 
            this.ovalShape1.BackgroundImage = global::typingmaster.Properties.Resources.images;
            this.ovalShape1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ovalShape1.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dot;
            this.ovalShape1.Location = new System.Drawing.Point(1106, 38);
            this.ovalShape1.Name = "ovalShape1";
            this.ovalShape1.Size = new System.Drawing.Size(158, 120);
            // 
            // timer3
            // 
            this.timer3.Interval = 1;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(894, 310);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 21);
            this.label2.TabIndex = 23;
            this.label2.Tag = "1";
            this.label2.Text = "Restart";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Black;
            this.label3.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(894, 346);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 21);
            this.label3.TabIndex = 24;
            this.label3.Tag = "1";
            this.label3.Text = "pause";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = global::typingmaster.Properties.Resources.r800_10000112_orig;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(972, 507);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lh);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lb);
            this.Controls.Add(this.lc);
            this.Controls.Add(this.ld);
            this.Controls.Add(this.le);
            this.Controls.Add(this.lf);
            this.Controls.Add(this.lg);
            this.Controls.Add(this.la);
            this.Controls.Add(this.shapeContainer1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label la;
        private System.Windows.Forms.Label lg;
        private System.Windows.Forms.Label lf;
        private System.Windows.Forms.Label le;
        private System.Windows.Forms.Label ld;
        private System.Windows.Forms.Label lc;
        private System.Windows.Forms.Label lb;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lh;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.TextBox textBox3;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape2;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape1;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

