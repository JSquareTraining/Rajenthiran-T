﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace user_control1
{
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }
        int i = 5;
        public int max_leg
        {
            get
            {
                return i;
            }
            set
            {
                i = value;
            }
        }
        string n, n1, p, r;

        string a;

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string s1 = textBox1.Text;

            foreach (char s in s1)
            {
                n = s.ToString();
                if (n == "@")
                {
                    n1 = "@";
                }
                else if (n == "g")
                {
                    n1 += "g";
                }
            }

            foreach (char s in s1)

                a = s.ToString();

            if (a == "@")
            {
                n1 = "@";
            }
            else if (a == "y")
            {
                n1 += "y";
            }



            if (n1 == "@g")
            {
                string p = s1.Remove(s1.IndexOf('@'));

                r = p + n1;


                textBox1.Text = r + "mail.com";
                textBox1.BackColor = Color.Yellow;
            }
            else if (n1 == "@y")
            {
                string p = s1.Remove(s1.IndexOf('@'));
                r = p + n1;
                textBox1.Text = r + "ahoo.com";
                textBox1.BackColor = Color.Blue;
            }


        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

            int s = textBox2.Text.Length;

            
            if (s >= 8)
            {
                button1.Enabled = true;
                textBox2.BackColor = Color.LightBlue;
                

            }
          /*  else if(s<=8)
            {
                label3.Text = "sorry your password is lessthen eight leters";

            }*/
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int i = 0;
            int j = 0;
            foreach (char s in textBox2.Text)
            {
                if (char.IsLetter(s))
                {
                    i = 1;
                }
                foreach (char a in textBox2.Text)
                {
                    if (char.IsNumber(a))
                    {
                        j = 1;
                    }
                }
                if (i == 1 && j == 1)
                {


                    /* int i = 0;
                     int j=0;
                     foreach (char s in textBox2.Text)
                     {
                         if (char.IsNumber(s))
                         {
                             i = 1;
                         }
                         else   if (char.IsLetter(s))
                         {
                             j = 1;
                         }

                     }
                     if (i == 1 && j == 1)
                     {
                         MessageBox.Show("success");
                     }
                     else
                     {
                         MessageBox.Show("invalid");
                     }*/

                    /*  int i = 0;
                      int j = 0;
                      foreach (char s in textBox2.Text)
                      {
                          if (char.IsNumber(s))
                          {
                              i = 1;
                          }
                          else if (char.IsLetter(s))
                          {
                              j = 1;
                          }
                          if (i == 1 && j == 1)
              
                          {*/
                    if (textBox1.Text == "raja.india3@gmail.com" && textBox2.Text == "1234567a")
                    {
                        MessageBox.Show("your login success");
                    }

                }
                else
                {
                    MessageBox.Show("sorry your login not success");
                }
                    
                }
            }
        }
            
        }
    
    

