﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace ADO_THREE_TIER_PROJECT
{
    class logical
    {
        string qry;
        public string query
        {
            get
            {
                return qry;
            }
            set
            {
                qry = value;
            }

        }
        SqlConnection sc = new SqlConnection("Data Source=RAJENTHIRANT\\SQLEXPRESS;Initial Catalog=master;Integrated Security=True");
        //Properties.Settings ps = new Properties.Settings();

        public void connection()
        {
            sc.Close();
          //  ps.conn = sc.ConnectionString;
            sc.Open();
        }
        public int execute()
        {
            sc.Close();
            connection();
            SqlCommand cmd = new SqlCommand(qry, sc);
           int i= cmd.ExecuteNonQuery();
           sc.Close();
           return i;
           
        }
        public DataSet adapt()
        {
            DataSet ds=new DataSet();
            connection();
            SqlDataAdapter sda = new SqlDataAdapter(qry, sc);
            sda.Fill(ds, "temp");
            sc.Close();
            return ds;
 
        }
        public SqlDataReader read()
        {
            connection();
            SqlDataReader sdr;
            SqlCommand cmd = new SqlCommand(qry, sc);
            sdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
          
            return sdr;

        }
    }
}
