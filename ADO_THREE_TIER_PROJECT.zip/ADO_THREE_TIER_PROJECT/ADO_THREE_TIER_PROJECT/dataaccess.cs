﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace ADO_THREE_TIER_PROJECT
{
    class dataaccess
    {
        logical ll = new logical();
        public int insert(string a, string b,string c)
        {
            string s = "insert into std values('" + a + "','" + b + "','" + c + "')";
            ll.query = s;
            return ll.execute();
        }
        public DataSet find()
        {
            string s = "select * from std";
            ll.query = s;
            return ll.adapt();

        }
        public SqlDataReader update(string a,string b,string c)
        {
            string s = "update std set sname='" + a + "' ,city='" + b + "' where sno='" + c+"'";
            ll.query = s;
            return ll.read();
        }
    }
}
