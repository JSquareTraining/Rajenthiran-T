﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Resources;

namespace ADO_THREE_TIER_PROJECT
{
    class loggical
    {
        public string _con;
        public string connection
        {
            get
            {
                return _con;
            }
            set
            {
                _con = value;
            }
        }
        public string _qry;
        public string query
        {
            get
            {
                return _qry;
            }
            set
            {
                _qry = value;
            }
        }
        public void connection_string()
        {
            Properties.Settings ps = new Properties.Settings();
            connection = ps.conn;
        }
        public int procc()
        {
            try
            {
                connection_string();
                SqlConnection con = new SqlConnection();
                con.ConnectionString = _con;
                con.Open();
                SqlCommand cmd = new SqlCommand(_qry, con);
                cmd.ExecuteNonQuery();
                con.Close();
                return 1;
            }
            catch (Exception ex)
            {
                return -1;
            }
            }
    }
}
