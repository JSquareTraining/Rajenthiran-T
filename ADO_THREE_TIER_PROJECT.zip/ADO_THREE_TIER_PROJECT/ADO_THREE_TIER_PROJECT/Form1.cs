﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ADO_THREE_TIER_PROJECT
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        dataaccess da = new dataaccess();
        private void button1_Click(object sender, EventArgs e)
        {
            da.insert(textBox1.Text, textBox2.Text, textBox3.Text);
            view();
           
        }
        DataSet ds = new DataSet();
     
        public void view()
        {
            ds = da.find();
            dataGridView1.DataSource = ds.Tables[0].DefaultView;
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            view();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            da.update(textBox1.Text, textBox2.Text, textBox3.Text);
            view();
        }
    }
}
