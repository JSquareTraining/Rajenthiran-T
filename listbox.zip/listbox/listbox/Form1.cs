﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace listbox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // int[] i = { 2, 45, 67, 78 };
            // for (int j = 0; j <i.Length; j++)
            /*foreach(int j in i)
            {
                MessageBox.Show(j.ToString());
            }
            foreach (CheckBox c in groupBox1.Controls)
            {
                if (c.Checked == true)
                {
                    MessageBox.Show(c.Text);
                }
            }
            foreach (char s in textBox1.Text)
            {
                MessageBox.Show(s.ToString());
            }*/
            //listBox1.Items.Add("june");
            //listBox1.Items.Add("july");
            //MessageBox.Show(listBox1.Items.Count.ToString());
            // MessageBox.Show(listBox1.SelectedItems.Count.ToString());


            /*int i = listBox1.SelectedItems.Count;
            for (int j = 0; j < i; j++)
            {
                MessageBox.Show(listBox1.Items[j].ToString());
            }*/
            /* string c = "";
             int j = 0;
             string a = listBox1.SelectedItem.ToString();
             foreach (char s in a)
             {
                //  c += s.ToString();
                 j += 1;
               
             }
             //int r = c.Length;
             MessageBox.Show(j.ToString());
             int f = listBox1.SelectedItems.Count;
             MessageBox.Show(f.ToString());
            // string y = listBox1.SelectedItems.ToString();
             foreach (string s in listBox1.SelectedItems)
             {
                 //  c += s.ToString();
                 MessageBox.Show(s.ToString()); 

             }*/
            // MessageBox.Show(y.ToString()); 


            /* int i = listBox1.SelectedItems.Count;.
             for (int j = 0; j < i; j++)
             {
                 MessageBox.Show(listBox1.Items[j].ToString());
             }*/
           /* foreach (char s in textBox1.Text)
            {
                if (char.IsNumber(s))
                {

                    MessageBox.Show(s.ToString());
                }
            }*/
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
           // int i = listBox1.SelectedItems.Count;
           //foreach(string s in listBox1.SelectedItems)
            //{

            //    listBox2.Items.Add(s);
          //  }
            int i = listBox1.SelectedItems.Count;
            for (int j = 0; j < i; j++)
            {

                listBox2.Items.Add(listBox1.SelectedItems[j].ToString());
               // listBox1.Items.Remove(listBox1.SelectedItems[j].ToString());
            }
                for (int k = 0; k< i; k++)
                {

                    listBox1.Items.Remove(listBox1.SelectedItems[0]);

                }
                listBox2.BackColor = Color.Green;
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
           // int i=listBox1.Items.Count;
            //for (int j = 0; j < i; j++)
           // {
            
            //    listBox2.SelectedItems.Add (listBox1.Items[j].ToString());

//            }
            foreach (string s in listBox1.Items)
            {
                listBox2.Items.Add(s.ToString());

            }
            listBox1.Items.Clear();
            listBox2.BackColor = Color.HotPink;
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int i = listBox2.SelectedItems.Count;
            for (int j = 0; j < i; j++)
            {
                listBox1.Items.Add(listBox2.SelectedItems[j].ToString());
            }
            for(int k=0;k<i;k++)
            {

                listBox2.Items.Remove(listBox2.SelectedItems[0].ToString());
            }
            listBox1.BackColor = Color.LightGray;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int i = listBox2.Items.Count;
            for (int j = 0; j < i; j++)
            {
                listBox1.Items.Add(listBox2.Items[j].ToString());
            }
            listBox2.Items.Clear();
            listBox1.BackColor = Color.Aqua;
        }
    }
}

