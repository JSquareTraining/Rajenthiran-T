﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;

namespace tab_control
{
    /// <summary>
    /// online exam using tab control
    /// </summary>
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {

            //int i=0;
            Properties.Settings ps = new Properties.Settings();
            ResourceManager rm = new ResourceManager("tab_control.Properties.Resources", Assembly.GetExecutingAssembly());
            InitLayout();
            if (checkBox1.Checked == true && checkBox2.Checked == false && checkBox3.Checked == false)
            {
                tabControl1.TabPages.Remove(tabPage1);
                tabControl1.TabPages.Add(tabPage2);
                //tabControl1.TabPages.Remove(tabPage4);
                //tabControl1.TabPages.Remove(tabPage5);
                //tabControl1.TabPages.Remove(tabPage3);
                tabControl1.SelectedTab = tabPage2;
                button10.Visible = false;
                button12.Visible = false;
                button6.Visible = false;
                if (ps.c == "1")
                {
                    //tabControl1.SelectedTab = tabPage2;

                    label2.Text = rm.GetString("cqa");
                    label4.Text = rm.GetString("cqb");
                    label5.Text = rm.GetString("cqc");
                    radioButton3.Text = rm.GetString("caa");
                    radioButton13.Text = rm.GetString("cab");
                    radioButton8.Text = rm.GetString("cac");
                    ps.c = "2";
                    ps.Save();


                }
                else if (ps.c == "2")
                {
                    //  tabControl1.SelectedTab = tabPage2;

                    label2.Text = rm.GetString("cqd");
                    label4.Text = rm.GetString("cqe");
                    label5.Text = rm.GetString("cqf");
                    radioButton3.Text = rm.GetString("cad");
                    radioButton13.Text = rm.GetString("cae");
                    radioButton8.Text = rm.GetString("caf");

                    ps.c = "3";
                    ps.Save();
                }
                else if (ps.c == "3")
                {
                    // tabControl1.SelectedTab = tabPage2;

                    label2.Text = rm.GetString("cqg");
                    label4.Text = rm.GetString("cqh");
                    label5.Text = rm.GetString("cqi");
                    radioButton3.Text = rm.GetString("cag");
                    radioButton13.Text = rm.GetString("cah");
                    radioButton8.Text = rm.GetString("cai");

                    ps.c = "1";
                    ps.Save();
                }


            }
           else if (checkBox1.Checked == false && checkBox2.Checked == true && checkBox3.Checked == false)
            {
                tabControl1.TabPages.Remove(tabPage1);
                tabControl1.TabPages.Add(tabPage4);
               // tabControl1.TabPages.Remove(tabPage5);
               // tabControl1.TabPages.Remove(tabPage2);
               // tabControl1.TabPages.Remove(tabPage2);
                tabControl1.SelectedTab = tabPage4;
                button7.Visible = false;
                button8.Visible = false;
                button13.Visible = false;
                if (ps.cpp == "2")
                {
                    //tabControl1.SelectedTab = tabPage2;

                    label7.Text = rm.GetString("ccqa");
                    label8.Text = rm.GetString("ccqb");
                    label9.Text = rm.GetString("ccqc");
                    radioButton15.Text = rm.GetString("ccaa");
                    radioButton19.Text = rm.GetString("ccab");
                    radioButton21.Text = rm.GetString("ccac");

                    ps.cpp = "3";
                    ps.Save();
                }
                else if (ps.cpp == "3")
                {
                    //tabControl1.SelectedTab = tabPage2;

                    label7.Text = rm.GetString("ccqd");
                    label8.Text = rm.GetString("ccqe");
                    label9.Text = rm.GetString("ccqf");
                    radioButton15.Text = rm.GetString("ccad");
                    radioButton19.Text = rm.GetString("ccae");
                    radioButton21.Text = rm.GetString("ccaf");

                    ps.cpp = "4";
                    ps.Save();
                }
                else if (ps.cpp == "4")
                {
                    //tabControl1.SelectedTab = tabPage2;

                    label7.Text = rm.GetString("ccqg");
                    label8.Text = rm.GetString("ccqh");
                    label9.Text = rm.GetString("ccqi");
                    radioButton15.Text = rm.GetString("ccag");
                    radioButton19.Text = rm.GetString("ccah");
                    radioButton21.Text = rm.GetString("ccai");

                    ps.cpp = "2";
                    ps.Save();
                }

            }
            else if (checkBox1.Checked == false && checkBox2.Checked == false & checkBox3.Checked == true)
            {
                tabControl1.TabPages.Remove(tabPage1);
                tabControl1.TabPages.Add(tabPage5);
                //tabControl1.TabPages.Remove(tabPage4);
                tabControl1.SelectedTab = tabPage5;
                button9.Visible = false;
                button14.Visible = false;
                button11.Visible = false;
                if (ps.net == "3")
                {
                    //tabControl1.SelectedTab = tabPage2;

                    label13.Text = rm.GetString("nqa");
                    label14.Text = rm.GetString("nqb");
                    label15.Text = rm.GetString("nqc");
                    radioButton26.Text = rm.GetString("naa");
                    radioButton28.Text = rm.GetString("nab");
                    radioButton30.Text = rm.GetString("nac");

                    ps.net = "4";
                    ps.Save();
                }
                else if (ps.net == "4")
                {
                    //tabControl1.SelectedTab = tabPage2;

                    label13.Text = rm.GetString("nqd");
                    label14.Text = rm.GetString("nqe");
                    label15.Text = rm.GetString("nqf");
                    radioButton26.Text = rm.GetString("nad");
                    radioButton28.Text = rm.GetString("nae");
                    radioButton30.Text = rm.GetString("naf");

                    ps.net = "5";
                    ps.Save();
                }
                else if (ps.net == "5")
                {
                    //tabControl1.SelectedTab = tabPage2;

                    label13.Text = rm.GetString("nqg");
                    label14.Text = rm.GetString("nqh");
                    label15.Text = rm.GetString("nqi");
                    radioButton26.Text = rm.GetString("nag");
                    radioButton28.Text = rm.GetString("nah");
                    radioButton30.Text = rm.GetString("nai");

                    ps.net = "3";
                    ps.Save();
                }

            }
            else if (checkBox1.Checked == true && checkBox2.Checked == true & checkBox3.Checked == false)
            {
                tabControl1.TabPages.Remove(tabPage4);
                tabControl1.TabPages.Remove(tabPage5);
                tabControl1.TabPages.Add(tabPage2);
                tabControl1.TabPages.Remove(tabPage3);
                tabControl1.TabPages.Remove(tabPage1);
                button6.Visible = false;
                button10.Visible = false;
                button3.Visible = false;
                tabControl1.SelectedTab = tabPage2;
                if (ps.c == "1")
                {
                    //tabControl1.SelectedTab = tabPage2;

                    label2.Text = rm.GetString("cqa");
                    label4.Text = rm.GetString("cqb");
                    label5.Text = rm.GetString("cqc");
                    radioButton3.Text = rm.GetString("caa");
                    radioButton13.Text = rm.GetString("cab");
                    radioButton8.Text = rm.GetString("cac");
                    ps.c = "2";
                    ps.Save();


                }
                else if (ps.c == "2")
                {
                    //  tabControl1.SelectedTab = tabPage2;

                    label2.Text = rm.GetString("cqd");
                    label4.Text = rm.GetString("cqe");
                    label5.Text = rm.GetString("cqf");
                    radioButton3.Text = rm.GetString("cad");
                    radioButton13.Text = rm.GetString("cae");
                    radioButton8.Text = rm.GetString("caf");

                    ps.c = "3";
                    ps.Save();
                }
                else if (ps.c == "3")
                {
                    // tabControl1.SelectedTab = tabPage2;

                    label2.Text = rm.GetString("cqg");
                    label4.Text = rm.GetString("cqh");
                    label5.Text = rm.GetString("cqi");
                    radioButton3.Text = rm.GetString("cag");
                    radioButton13.Text = rm.GetString("cah");
                    radioButton8.Text = rm.GetString("cai");

                    ps.c = "1";
                    ps.Save();
                }


            }
            else if (checkBox1.Checked == false && checkBox2.Checked == true && checkBox3.Checked == true)
            {
                button7.Visible = false;
                button5.Visible = false;
                button13.Visible = false;
                tabControl1.SelectedTab = tabPage4;
                tabControl1.TabPages.Add(tabPage4);
                tabControl1.TabPages.Remove(tabPage1);
                tabControl1.TabPages.Remove(tabPage2);
                tabControl1.TabPages.Remove(tabPage3);
                tabControl1.TabPages.Remove(tabPage5);
              

                if (ps.cpp == "2")
                {
                    //tabControl1.SelectedTab = tabPage2;

                    label7.Text = rm.GetString("ccqa");
                    label8.Text = rm.GetString("ccqb");
                    label9.Text = rm.GetString("ccqc");
                    radioButton15.Text = rm.GetString("ccaa");
                    radioButton19.Text = rm.GetString("ccab");
                    radioButton21.Text = rm.GetString("ccac");

                    ps.cpp = "3";
                    ps.Save();
                }
                else if (ps.cpp == "3")
                {
                    //tabControl1.SelectedTab = tabPage2;

                    label7.Text = rm.GetString("ccqd");
                    label8.Text = rm.GetString("ccqe");
                    label9.Text = rm.GetString("ccqf");
                    radioButton15.Text = rm.GetString("ccad");
                    radioButton19.Text = rm.GetString("ccae");
                    radioButton21.Text = rm.GetString("ccaf");

                    ps.cpp = "4";
                    ps.Save();
                }
                else if (ps.cpp == "4")
                {
                    //tabControl1.SelectedTab = tabPage2;

                    label7.Text = rm.GetString("ccqg");
                    label8.Text = rm.GetString("ccqh");
                    label9.Text = rm.GetString("ccqi");
                    radioButton15.Text = rm.GetString("ccag");
                    radioButton19.Text = rm.GetString("ccah");
                    radioButton21.Text = rm.GetString("ccai");

                    ps.cpp = "2";
                    ps.Save();
                }





            }
            else if (checkBox1.Checked == true && checkBox2.Checked == false && checkBox3.Checked == true)
            {
               
                tabControl1.TabPages.Add(tabPage2);
                tabControl1.SelectedTab = tabPage2;
                tabControl1.TabPages.Remove(tabPage5);
                tabControl1.TabPages.Remove(tabPage4);
                tabControl1.TabPages.Remove(tabPage3);
                tabControl1.TabPages.Remove(tabPage1);
                //tabControl1.TabPages.Add(tabPage5);
           
                button12.Visible = false;
                button6.Visible = false;
                button3.Visible = false;
                if (ps.c == "1")
                {
                    //tabControl1.SelectedTab = tabPage2;

                    label2.Text = rm.GetString("cqa");
                    label4.Text = rm.GetString("cqb");
                    label5.Text = rm.GetString("cqc");
                    radioButton3.Text = rm.GetString("caa");
                    radioButton13.Text = rm.GetString("cab");
                    radioButton8.Text = rm.GetString("cac");
                    ps.c = "2";
                    ps.Save();


                }
                else if (ps.c == "2")
                {
                    //  tabControl1.SelectedTab = tabPage2;

                    label2.Text = rm.GetString("cqd");
                    label4.Text = rm.GetString("cqe");
                    label5.Text = rm.GetString("cqf");
                    radioButton3.Text = rm.GetString("cad");
                    radioButton13.Text = rm.GetString("cae");
                    radioButton8.Text = rm.GetString("caf");

                    ps.c = "3";
                    ps.Save();
                }
                else if (ps.c == "3")
                {
                    // tabControl1.SelectedTab = tabPage2;

                    label2.Text = rm.GetString("cqg");
                    label4.Text = rm.GetString("cqh");
                    label5.Text = rm.GetString("cqi");
                    radioButton3.Text = rm.GetString("cag");
                    radioButton13.Text = rm.GetString("cah");
                    radioButton8.Text = rm.GetString("cai");

                    ps.c = "1";
                    ps.Save();
                }


            }

            else if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == true)
            {

                
                tabControl1.TabPages.Add(tabPage2);
                tabControl1.TabPages.Remove(tabPage1);
                tabControl1.TabPages.Remove(tabPage3);
                tabControl1.TabPages.Remove(tabPage4);
                tabControl1.TabPages.Remove(tabPage5);
                tabControl1.SelectedTab = tabPage2;
                button12.Visible = false;
                button10.Visible = false;
                button3.Visible = false;
                if (ps.c == "1")
                {
                    //tabControl1.SelectedTab = tabPage2;

                    label2.Text = rm.GetString("cqa");
                    label4.Text = rm.GetString("cqb");
                    label5.Text = rm.GetString("cqc");
                    radioButton3.Text = rm.GetString("caa");
                    radioButton13.Text = rm.GetString("cab");
                    radioButton8.Text = rm.GetString("cac");
                    ps.c = "2";
                    ps.Save();


                }
                else if (ps.c == "2")
                {
                    //  tabControl1.SelectedTab = tabPage2;

                    label2.Text = rm.GetString("cqd");
                    label4.Text = rm.GetString("cqe");
                    label5.Text = rm.GetString("cqf");
                    radioButton3.Text = rm.GetString("cad");
                    radioButton13.Text = rm.GetString("cae");
                    radioButton8.Text = rm.GetString("caf");

                    ps.c = "3";
                    ps.Save();
                }
                else if (ps.c == "3")
                {
                    // tabControl1.SelectedTab = tabPage2;

                    label2.Text = rm.GetString("cqg");
                    label4.Text = rm.GetString("cqh");
                    label5.Text = rm.GetString("cqi");
                    radioButton3.Text = rm.GetString("cag");
                    radioButton13.Text = rm.GetString("cah");
                    radioButton8.Text = rm.GetString("cai");

                    ps.c = "1";
                    ps.Save();
                }

            }
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
            /* if (textBox1.Text == "")
             {
                 tabControl1.SelectedTab = tabControl1.TabPages[0];
             }*/
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
            /*if (textBox2.Text == "tr")
            {
                tabControl1.SelectedTab = tabControl1.TabPages[1];

            }*/
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //  tabControl1.TabPages.Add("resuld");
        }


        private void rb(object sender, EventArgs e)
        {
            RadioButton rb = new RadioButton();
            rb.Checked = false;

        }
          protected override void InitLayout()
          {
              radioButton3.Checked = false;
              radioButton4.Checked = false;
              radioButton5.Checked = false;
              radioButton6.Checked = false;
              radioButton7.Checked = false;
              radioButton8.Checked = false;
              radioButton9.Checked = false;
              radioButton10.Checked = false;
              radioButton11.Checked = false;
              radioButton12.Checked = false;
              radioButton13.Checked = false;
              radioButton14.Checked = false;

              base.InitLayout();

          }

        private void button3_Click_1(object sender, EventArgs e)
        {
            tabControl1.TabPages.Add(tabPage3);
            tabControl1.TabPages.Remove(tabPage2);
            if (checkBox1.Checked == true && checkBox2.Checked == false && checkBox3.Checked == false)
            {
                tabControl1.SelectedTab = tabPage3;

                if (radioButton3.Checked == true)
                {
                    lbl_1.BackColor = Color.Green;

                }
                else
                {
                    tabControl1.SelectedTab = tabPage3;

                    lbl_1.BackColor = Color.Red;
                }
                if (radioButton13.Checked == true)
                {
                    lbl_2.BackColor = Color.Green;
                }
                else
                {
                    lbl_2.BackColor = Color.Red;
                }
                if (radioButton8.Checked == true)
                {
                    lbl_3.BackColor = Color.Green;
                }
                else
                {

                    lbl_3.BackColor = Color.Red;
                }
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            //tabControl1.TabPages.Add(tabPage2);
            tabControl1.SelectedTab = tabPage1;
        }
        //private void tabpage4_Click(object sender, EventArgs e)
        // {
        //tabControl1.TabPages.Add(tabPage2);
        //  }



        private void button5_Click(object sender, EventArgs e)
        {
            tabControl1.TabPages.Add(tabPage3);
            tabControl1.TabPages.Remove(tabPage4);
            if (checkBox1.Checked == false && checkBox2.Checked == true && checkBox3.Checked == false)
            {
                tabControl1.SelectedTab = tabPage3;

                if (radioButton15.Checked == true)
                {
                    lbl_4.BackColor = Color.Green;

                }
                else
                {

                    lbl_4.BackColor = Color.Red;
                }
                if (radioButton19.Checked == true)
                {
                    lbl_5.BackColor = Color.Green;
                }
                else
                {
                    lbl_5.BackColor = Color.Red;
                }
                if (radioButton21.Checked == true)
                {
                    lbl_6.BackColor = Color.Green;
                }
                else
                {

                    lbl_6.BackColor = Color.Red;
                }
            }
        }


        private void button4_Click(object sender, EventArgs e)
        {
            tabControl1.TabPages.Remove(tabPage5);
            tabControl1.TabPages.Add(tabPage3);
            if (checkBox1.Checked == false && checkBox2.Checked == false && checkBox3.Checked == true)
            {
                tabControl1.SelectedTab = tabPage3;

                if (radioButton26.Checked == true)
                {
                    lbl_7.BackColor = Color.Green;

                }
                else
                {

                    lbl_7.BackColor = Color.Red;
                }
                if (radioButton28.Checked == true)
                {
                    lbl_8.BackColor = Color.Green;
                }
                else
                {
                    lbl_8.BackColor = Color.Red;
                }
                if (radioButton30.Checked == true)
                {
                    lbl_9.BackColor = Color.Green;
                }
                else
                {

                    lbl_9.BackColor = Color.Red;
                }
            }
        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Properties.Settings ps = new Properties.Settings();
            ResourceManager rm = new ResourceManager("tab_control.Properties.Resources", Assembly.GetExecutingAssembly());
            tabControl1.TabPages.Add(tabPage4);
            tabControl1.TabPages.Remove(tabPage1);
            tabControl1.TabPages.Remove(tabPage2);
            tabControl1.TabPages.Remove(tabPage3);
            tabControl1.TabPages.Remove(tabPage5);
            button7.Visible = false;
            button5.Visible = false;
            button8.Visible = false;
            button6.Visible = false;
            tabControl1.SelectedTab = tabPage4;
            if (ps.cpp == "2")
            {
               // tabControl1.SelectedTab = tabPage4;

                label7.Text = rm.GetString("ccqa");
                label8.Text = rm.GetString("ccqb");
                label9.Text = rm.GetString("ccqc");
                radioButton15.Text = rm.GetString("ccaa");
                radioButton19.Text = rm.GetString("ccab");
                radioButton21.Text = rm.GetString("ccac");

                ps.cpp = "3";
                ps.Save();
            }
            else if (ps.cpp == "3")
            {
                //tabControl1.SelectedTab = tabPage4;

                label7.Text = rm.GetString("ccqd");
                label8.Text = rm.GetString("ccqe");
                label9.Text = rm.GetString("ccqf");
                radioButton15.Text = rm.GetString("ccad");
                radioButton19.Text = rm.GetString("ccae");
                radioButton21.Text = rm.GetString("ccaf");

                ps.cpp = "4";
                ps.Save();
            }
            else if (ps.cpp == "4")
            {
               // tabControl1.SelectedTab = tabPage4;

                label7.Text = rm.GetString("ccqg");
                label8.Text = rm.GetString("ccqh");
                label9.Text = rm.GetString("ccqi");
                radioButton15.Text = rm.GetString("ccag");
                radioButton19.Text = rm.GetString("ccah");
                radioButton21.Text = rm.GetString("ccai");

                ps.cpp = "2";
                ps.Save();

            }

        }


        private void button7_Click(object sender, EventArgs e)
        {
            tabControl1.TabPages.Add(tabPage3);
            tabControl1.TabPages.Remove(tabPage1);
            tabControl1.TabPages.Remove(tabPage2);
            tabControl1.TabPages.Remove(tabPage5);
            tabControl1.TabPages.Remove(tabPage4);
            tabControl1.SelectedTab = tabPage3;
            if (radioButton3.Checked == true)
            {
                lbl_1.BackColor = Color.Green;

            }
            else
            {
                tabControl1.SelectedTab = tabPage3;

                lbl_1.BackColor = Color.Red;
            }
            if (radioButton13.Checked == true)
            {
                lbl_2.BackColor = Color.Green;
            }
            else
            {
                lbl_2.BackColor = Color.Red;
            }
            if (radioButton8.Checked == true)
            {
                lbl_3.BackColor = Color.Green;
            }
            else
            {

                lbl_3.BackColor = Color.Red;
            }



            if (radioButton15.Checked == true)
            {
                lbl_4.BackColor = Color.Green;

            }
            else
            {

                lbl_4.BackColor = Color.Red;
            }
            if (radioButton19.Checked == true)
            {
                lbl_5.BackColor = Color.Green;
            }
            else
            {
                lbl_5.BackColor = Color.Red;
            }
            if (radioButton21.Checked == true)
            {
                lbl_6.BackColor = Color.Green;
            }
            else
            {

                lbl_6.BackColor = Color.Red;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Properties.Settings ps = new Properties.Settings();
            ResourceManager rm = new ResourceManager("tab_control.Properties.Resources", Assembly.GetExecutingAssembly());
            button4.Visible = false;
            button11.Visible = false;
            button14.Visible = false;
            tabControl1.TabPages.Remove(tabPage2);
            tabControl1.TabPages.Remove(tabPage4);
            tabControl1.TabPages.Add(tabPage5);
           
            tabControl1.SelectedTab = tabPage5;
            
            if (ps.net == "3")
            {
                //tabControl1.SelectedTab = tabPage2;

                label13.Text = rm.GetString("nqa");
                label14.Text = rm.GetString("nqb");
                label15.Text = rm.GetString("nqc");
                radioButton26.Text = rm.GetString("naa");
                radioButton28.Text = rm.GetString("nab");
                radioButton30.Text = rm.GetString("nac");

                ps.net = "4";
                ps.Save();
            }
            else if (ps.net == "4")
            {
                //tabControl1.SelectedTab = tabPage2;

                label13.Text = rm.GetString("nqd");
                label14.Text = rm.GetString("nqe");
                label15.Text = rm.GetString("nqf");
                radioButton26.Text = rm.GetString("nad");
                radioButton28.Text = rm.GetString("nae");
                radioButton30.Text = rm.GetString("naf");

                ps.net = "5";
                ps.Save();
            }
            else if (ps.net == "5")
            {
                //tabControl1.SelectedTab = tabPage2;

                label13.Text = rm.GetString("nqg");
                label14.Text = rm.GetString("nqh");
                label15.Text = rm.GetString("nqi");
                radioButton26.Text = rm.GetString("nag");
                radioButton28.Text = rm.GetString("nah");
                radioButton30.Text = rm.GetString("nai");

                ps.net = "3";
                ps.Save();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            tabControl1.TabPages.Add(tabPage3);
            tabControl1.TabPages.Remove(tabPage1);
            tabControl1.TabPages.Remove(tabPage2);
            tabControl1.TabPages.Remove(tabPage4);
            tabControl1.TabPages.Remove(tabPage5);
            tabControl1.SelectedTab = tabPage3;

            if (radioButton15.Checked == true)
            {
                lbl_4.BackColor = Color.Green;

            }
            else
            {

                lbl_4.BackColor = Color.Red;
            }
            if (radioButton19.Checked == true)
            {
                lbl_5.BackColor = Color.Green;
            }
            else
            {
                lbl_5.BackColor = Color.Red;
            }
            if (radioButton21.Checked == true)
            {
                lbl_6.BackColor = Color.Green;
            }
            else
            {

                lbl_6.BackColor = Color.Red;
            }
            if (radioButton26.Checked == true)
            {
                lbl_7.BackColor = Color.Green;

            }
            else
            {

                lbl_7.BackColor = Color.Red;
            }
            if (radioButton28.Checked == true)
            {
                lbl_8.BackColor = Color.Green;
            }
            else
            {
                lbl_8.BackColor = Color.Red;
            }
            if (radioButton30.Checked == true)
            {
                lbl_9.BackColor = Color.Green;
            }
            else
            {

                lbl_9.BackColor = Color.Red;
            }

        }

        private void button10_Click(object sender, EventArgs e)
        {
            tabControl1.TabPages.Add(tabPage5);
            Properties.Settings ps = new Properties.Settings();
            ResourceManager rm = new ResourceManager("tab_control.Properties.Resources", Assembly.GetExecutingAssembly());
            tabControl1.SelectedTab = tabPage5;
            tabControl1.TabPages.Remove(tabPage2);
            tabControl1.TabPages.Remove(tabPage4);
            
           
           
            button9.Visible = false;
            button4.Visible = false;
            button14.Visible = false;
            if (ps.net == "3")
            {
                //tabControl1.SelectedTab = tabPage2;

                label13.Text = rm.GetString("nqa");
                label14.Text = rm.GetString("nqb");
                label15.Text = rm.GetString("nqc");
                radioButton26.Text = rm.GetString("naa");
                radioButton28.Text = rm.GetString("nab");
                radioButton30.Text = rm.GetString("nac");

                ps.net = "4";
                ps.Save();
            }
            else if (ps.net == "4")
            {
                //tabControl1.SelectedTab = tabPage2;

                label13.Text = rm.GetString("nqd");
                label14.Text = rm.GetString("nqe");
                label15.Text = rm.GetString("nqf");
                radioButton26.Text = rm.GetString("nad");
                radioButton28.Text = rm.GetString("nae");
                radioButton30.Text = rm.GetString("naf");

                ps.net = "5";
                ps.Save();
            }
            else if (ps.net == "5")
            {
                //tabControl1.SelectedTab = tabPage2;

                label13.Text = rm.GetString("nqg");
                label14.Text = rm.GetString("nqh");
                label15.Text = rm.GetString("nqi");
                radioButton26.Text = rm.GetString("nag");
                radioButton28.Text = rm.GetString("nah");
                radioButton30.Text = rm.GetString("nai");

                ps.net = "3";
                ps.Save();
            }
        
        }

        private void button11_Click(object sender, EventArgs e)
        {
            tabControl1.TabPages.Add(tabPage3);
            tabControl1.TabPages.Remove(tabPage1);
            tabControl1.TabPages.Remove(tabPage2);
            tabControl1.TabPages.Remove(tabPage4);
            tabControl1.TabPages.Remove(tabPage5);
            tabControl1.SelectedTab = tabPage3;
            if (radioButton3.Checked == true)
            {
                lbl_1.BackColor = Color.Green;

            }
            else
            {
                tabControl1.SelectedTab = tabPage3;

                lbl_1.BackColor = Color.Red;
            }
            if (radioButton13.Checked == true)
            {
                lbl_2.BackColor = Color.Green;
            }
            else
            {
                lbl_2.BackColor = Color.Red;
            }
            if (radioButton8.Checked == true)
            {
                lbl_3.BackColor = Color.Green;
            }
            else
            {

                lbl_3.BackColor = Color.Red;
            }
            if (radioButton26.Checked == true)
            {
                lbl_7.BackColor = Color.Green;

            }
            else
            {

                lbl_7.BackColor = Color.Red;
            }
            if (radioButton28.Checked == true)
            {
                lbl_8.BackColor = Color.Green;
            }
            else
            {
                lbl_8.BackColor = Color.Red;
            }
            if (radioButton30.Checked == true)
            {
                lbl_9.BackColor = Color.Green;
            }
            else
            {

                lbl_9.BackColor = Color.Red;
            }


        }

        private void button12_Click(object sender, EventArgs e)
        {
            tabControl1.TabPages.Add(tabPage4);
            tabControl1.TabPages.Remove(tabPage2);
            tabControl1.TabPages.Remove(tabPage5);
            tabControl1.TabPages.Remove(tabPage1);
            tabControl1.TabPages.Remove(tabPage3);
            button8.Visible = false;
            button13.Visible = false;
            button5.Visible = false;
            Properties.Settings ps = new Properties.Settings();
            ResourceManager rm = new ResourceManager("tab_control.Properties.Resources", Assembly.GetExecutingAssembly());
           
            tabControl1.SelectedTab = tabPage4;

            if (ps.cpp == "2")
            {
                //tabControl1.SelectedTab = tabPage2;

                label7.Text = rm.GetString("ccqa");
                label8.Text = rm.GetString("ccqb");
                label9.Text = rm.GetString("ccqc");
                radioButton15.Text = rm.GetString("ccaa");
                radioButton19.Text = rm.GetString("ccab");
                radioButton21.Text = rm.GetString("ccac");

                ps.cpp = "3";
                ps.Save();
            }
            else if (ps.cpp == "3")
            {
                //tabControl1.SelectedTab = tabPage2;

                label7.Text = rm.GetString("ccqd");
                label8.Text = rm.GetString("ccqe");
                label9.Text = rm.GetString("ccqf");
                radioButton15.Text = rm.GetString("ccad");
                radioButton19.Text = rm.GetString("ccae");
                radioButton21.Text = rm.GetString("ccaf");

                ps.cpp = "4";
                ps.Save();
            }
            else if (ps.cpp == "4")
            {
                //tabControl1.SelectedTab = tabPage2;

                label7.Text = rm.GetString("ccqg");
                label8.Text = rm.GetString("ccqh");
                label9.Text = rm.GetString("ccqi");
                radioButton15.Text = rm.GetString("ccag");
                radioButton19.Text = rm.GetString("ccah");
                radioButton21.Text = rm.GetString("ccai");

                ps.cpp = "2";
                ps.Save();
            }

        }

        private void button13_Click(object sender, EventArgs e)
        {
            button9.Visible = false;
            button11.Visible = false;
            button4.Visible = false;
           
            tabControl1.TabPages.Add(tabPage5);
            tabControl1.TabPages.Remove(tabPage1);
            tabControl1.TabPages.Remove(tabPage2);
            tabControl1.TabPages.Remove(tabPage3);
            tabControl1.TabPages.Remove(tabPage4);

            Properties.Settings ps = new Properties.Settings();
            ResourceManager rm = new ResourceManager("tab_control.Properties.Resources", Assembly.GetExecutingAssembly());
            tabControl1.SelectedTab = tabPage5;
            if (ps.net == "3")
            {
                //tabControl1.SelectedTab = tabPage2;

                label13.Text = rm.GetString("nqa");
                label14.Text = rm.GetString("nqb");
                label15.Text = rm.GetString("nqc");
                radioButton26.Text = rm.GetString("naa");
                radioButton28.Text = rm.GetString("nab");
                radioButton30.Text = rm.GetString("nac");

                ps.net = "4";
                ps.Save();
            }
            else if (ps.net == "4")
            {
                //tabControl1.SelectedTab = tabPage2;

                label13.Text = rm.GetString("nqd");
                label14.Text = rm.GetString("nqe");
                label15.Text = rm.GetString("nqf");
                radioButton26.Text = rm.GetString("nad");
                radioButton28.Text = rm.GetString("nae");
                radioButton30.Text = rm.GetString("naf");

                ps.net= "5";
                ps.Save();
            }
            else if (ps.net == "5")
            {
                //tabControl1.SelectedTab = tabPage2;

                label13.Text = rm.GetString("nqg");
                label14.Text = rm.GetString("nqh");
                label15.Text = rm.GetString("nqi");
                radioButton26.Text = rm.GetString("nag");
                radioButton28.Text = rm.GetString("nah");
                radioButton30.Text = rm.GetString("nai");

                ps.net= "3";
                ps.Save();
            }

        }

        private void button14_Click(object sender, EventArgs e)
        {
            tabControl1.TabPages.Add(tabPage3);
            tabControl1.SelectedTab = tabPage3;
            tabControl1.TabPages.Remove(tabPage1);
            tabControl1.TabPages.Remove(tabPage2);
            tabControl1.TabPages.Remove(tabPage4);
            tabControl1.TabPages.Remove(tabPage5);
            if (radioButton3.Checked == true)
            {
                lbl_1.BackColor = Color.Green;

            }
            else
            {
                tabControl1.SelectedTab = tabPage3;

                lbl_1.BackColor = Color.Red;
            }
            if (radioButton13.Checked == true)
            {
                lbl_2.BackColor = Color.Green;
            }
            else
            {
                lbl_2.BackColor = Color.Red;
            }
            if (radioButton8.Checked == true)
            {
                lbl_3.BackColor = Color.Green;
            }
            else
            {

                lbl_3.BackColor = Color.Red;
            }
            if (radioButton15.Checked == true)
            {
                lbl_4.BackColor = Color.Green;

            }
            else
            {

                lbl_4.BackColor = Color.Red;
            }
            if (radioButton19.Checked == true)
            {
                lbl_5.BackColor = Color.Green;
            }
            else
            {
                lbl_5.BackColor = Color.Red;
            }
            if (radioButton21.Checked == true)
            {
                lbl_6.BackColor = Color.Green;
            }
            else
            {

                lbl_6.BackColor = Color.Red;
            }
            if (radioButton26.Checked == true)
            {
                lbl_7.BackColor = Color.Green;

            }
            else
            {

                lbl_7.BackColor = Color.Red;
            }
            if (radioButton28.Checked == true)
            {
                lbl_8.BackColor = Color.Green;
            }
            else
            {
                lbl_8.BackColor = Color.Red;
            }
            if (radioButton30.Checked == true)
            {
                lbl_9.BackColor = Color.Green;
            }
            else
            {

                lbl_9.BackColor = Color.Red;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            tabControl1.TabPages.Remove(tabPage2);
            tabControl1.TabPages.Remove(tabPage3);
            tabControl1.TabPages.Remove(tabPage4);
            tabControl1.TabPages.Remove(tabPage5);
        }
    }


}

