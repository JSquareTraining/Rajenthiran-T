﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace grid_find
{
    public partial class again : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack == true)
            {
               
                display();
            }
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            display();
        }
        bussiness bs=new bussiness();
        public void display()
        {
            DataSet ds=new DataSet();
            ds=bs.again();
        
            GridView1.DataSource = ds.Tables[0].DefaultView;
            GridView1.DataBind();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            display();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            
            TextBox txtname = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox1");
            TextBox txtmark1 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox2");
            TextBox txtmark2 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox3");

            bs.update(txtname.Text, txtmark1.Text, txtmark2.Text);
            display();

        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            TextBox txtname = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox1");
            bs.delete(txtname.Text);
            display();
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            TextBox txtname = (TextBox)GridView1.FooterRow.FindControl("");
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            Response.Redirect("gridfind.aspx?uname=raja&pwd=12345");
        }
    }
}