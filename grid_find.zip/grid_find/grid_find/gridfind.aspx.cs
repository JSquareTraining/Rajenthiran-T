﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace grid_find
{
    public partial class gridfind : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack == true)
            {
                full_view();
            }
        }
        bussiness bs = new bussiness();
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
           

                       

        }
        public void full_view()
        {
            DataSet ds = new DataSet();
            ds = bs.view();
            GridView1.DataSource = ds.Tables[0].DefaultView;
            GridView1.DataBind();
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            //GridView1.EditIndex = e.NewEditIndex;
            //full_view();
            GridView1.EditIndex = e.NewEditIndex;
            full_view();

        }

        protected void GridView1_RowEditing1(object sender, GridViewEditEventArgs e)
        {
            full_view();

        }

        protected void GridView1_RowCommand1(object sender, GridViewCommandEventArgs e)
        {
            TextBox txtname = (TextBox)GridView1.FooterRow.FindControl("TextBox4");
            TextBox txtmark = (TextBox)GridView1.FooterRow.FindControl("TextBox5");
            TextBox txtcity = (TextBox)GridView1.FooterRow.FindControl("TextBox6");
            Button txtin = (Button)GridView1.FooterRow.FindControl("Button5");
            if (e.CommandName=="Insert")
            {
                bs.insert(txtname.Text, txtmark.Text, txtcity.Text);
            }
            full_view();


        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            full_view();

        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            TextBox txtname = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox1");
            TextBox txtmark = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox2");
            TextBox txtcity = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox3");

            bs.update(txtname.Text, txtmark.Text, txtcity.Text);
            full_view();
        }


    }
}