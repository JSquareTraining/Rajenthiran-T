﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace grid_find
{
    
    public class bussiness
    {
        dataaccess da = new dataaccess();
        public int insert(string n, string m, string c)
        {
            string s = "insert into again values('" + n + "','" + m + "','" + c + "')";
            da.query = s;
            return da.execute();
        }
        public DataSet view()
        {
            string s = "select * from grid";
            da.query = s;
            return da.select();
        }
        public int update(string n,string m,string c)
        {
            string s = "update again set mark1='" + m + "',mark2='" + c + "' where name='" + n + "'";
            da.query = s;
           return da.execute();
        }
        public DataSet again()
        {
            string s = "select * from again";
            da.query = s;
            return da.select();
        }
        public int delete(string n)
        {
            string s = "delete from again where name='" + n + "'";
            da.query = s;
            return da.execute();

        }
    }
}