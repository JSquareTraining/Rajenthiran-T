﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace grid_find
{
    public class dataaccess
    {
        string qry;
        public string query
        {
            get
            {
                return qry;
            }
            set
            {
                qry = value;
                    
            }
        }
        SqlConnection sc = new SqlConnection("Data Source=RAJENTHIRANT\\SQLEXPRESS;Initial Catalog=master;Integrated Security=True");
        public int execute()
        {
            sc.Close();
            sc.Open();
            SqlCommand cmd = new SqlCommand(qry,sc);
            int i = cmd.ExecuteNonQuery();
            sc.Close();
            return i;
        }
        public DataSet select()
        {
            sc.Close();
            sc.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter sda = new SqlDataAdapter(qry,sc);
            sda.Fill(ds,"temp");
            return ds;
        }

    }
}