﻿namespace registration
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.uname2_txt = new System.Windows.Forms.TextBox();
            this.password2_txt = new System.Windows.Forms.TextBox();
            this.login = new System.Windows.Forms.Button();
            this.uname_lbl = new System.Windows.Forms.Label();
            this.password_lbl = new System.Windows.Forms.Label();
            this.city_lbl = new System.Windows.Forms.Label();
            this.name_lbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Maroon;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Lime;
            this.label1.Location = new System.Drawing.Point(255, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "USER NAME";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Lime;
            this.label2.Location = new System.Drawing.Point(254, 189);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "PASSWORD";
            // 
            // uname2_txt
            // 
            this.uname2_txt.Location = new System.Drawing.Point(387, 97);
            this.uname2_txt.Name = "uname2_txt";
            this.uname2_txt.Size = new System.Drawing.Size(100, 22);
            this.uname2_txt.TabIndex = 2;
            // 
            // password2_txt
            // 
            this.password2_txt.Location = new System.Drawing.Point(387, 184);
            this.password2_txt.Name = "password2_txt";
            this.password2_txt.Size = new System.Drawing.Size(100, 22);
            this.password2_txt.TabIndex = 3;
            this.password2_txt.UseSystemPasswordChar = true;
            this.password2_txt.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // login
            // 
            this.login.BackColor = System.Drawing.Color.Yellow;
            this.login.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.login.Location = new System.Drawing.Point(412, 269);
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(86, 34);
            this.login.TabIndex = 4;
            this.login.Text = "LOGIN";
            this.login.UseVisualStyleBackColor = false;
            this.login.Click += new System.EventHandler(this.button1_Click);
            // 
            // uname_lbl
            // 
            this.uname_lbl.AutoSize = true;
            this.uname_lbl.Location = new System.Drawing.Point(632, 100);
            this.uname_lbl.Name = "uname_lbl";
            this.uname_lbl.Size = new System.Drawing.Size(51, 17);
            this.uname_lbl.TabIndex = 5;
            this.uname_lbl.Text = "uname";
            this.uname_lbl.Visible = false;
            // 
            // password_lbl
            // 
            this.password_lbl.AutoSize = true;
            this.password_lbl.Location = new System.Drawing.Point(632, 189);
            this.password_lbl.Name = "password_lbl";
            this.password_lbl.Size = new System.Drawing.Size(68, 17);
            this.password_lbl.TabIndex = 6;
            this.password_lbl.Text = "password";
            this.password_lbl.Visible = false;
            // 
            // city_lbl
            // 
            this.city_lbl.AutoSize = true;
            this.city_lbl.Location = new System.Drawing.Point(632, 252);
            this.city_lbl.Name = "city_lbl";
            this.city_lbl.Size = new System.Drawing.Size(29, 17);
            this.city_lbl.TabIndex = 7;
            this.city_lbl.Text = "city";
            this.city_lbl.Visible = false;
            // 
            // name_lbl
            // 
            this.name_lbl.AutoSize = true;
            this.name_lbl.Location = new System.Drawing.Point(632, 52);
            this.name_lbl.Name = "name_lbl";
            this.name_lbl.Size = new System.Drawing.Size(43, 17);
            this.name_lbl.TabIndex = 8;
            this.name_lbl.Text = "name";
            this.name_lbl.Visible = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkRed;
            this.ClientSize = new System.Drawing.Size(828, 374);
            this.Controls.Add(this.name_lbl);
            this.Controls.Add(this.city_lbl);
            this.Controls.Add(this.password_lbl);
            this.Controls.Add(this.uname_lbl);
            this.Controls.Add(this.login);
            this.Controls.Add(this.password2_txt);
            this.Controls.Add(this.uname2_txt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox uname2_txt;
        private System.Windows.Forms.TextBox password2_txt;
        private System.Windows.Forms.Button login;
        public System.Windows.Forms.Label uname_lbl;
        public System.Windows.Forms.Label password_lbl;
        public System.Windows.Forms.Label city_lbl;
        public System.Windows.Forms.Label name_lbl;

    }
}