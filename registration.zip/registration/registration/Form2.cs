﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace registration
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult oo = new DialogResult();
            Form3 o3 = new Form3();
            Form1 o1 = new Form1();
           
          
            if (uname2_txt.Text == uname_lbl.Text && password2_txt.Text == password_lbl.Text)
            {
                oo = MessageBox.Show("login success ...do you want see your profile", "login", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);
                 
            }
            if(oo==DialogResult.Yes)
            {
               o3. label1.Text = name_lbl.Text;
               o3.label2.Text = uname_lbl.Text;
               o3.label3.Text = password_lbl.Text;
               o3. label4.Text = city_lbl.Text;
               o3.Show();
            }
            else if(oo==DialogResult.No)
            {
                MessageBox.Show("no");
            }
            else if(oo==DialogResult.Cancel)
            {
                MessageBox.Show("cancel");
         }
            else if (uname2_txt.Text == uname_lbl.Text)
            {
                MessageBox.Show("enter your password");
            }
           else if (password2_txt.Text == password_lbl.Text)
            {
                MessageBox.Show("enter your password");
            }
            else if (uname2_txt.Text == "" && password2_txt.Text == "")
            {
                MessageBox.Show("enter your user name and password");
            }
            else if (uname2_txt.Text != uname_lbl.Text && password2_txt.Text != password_lbl.Text)
            {
                MessageBox.Show("sorry your username or password is wrong");
            }
            uname2_txt.Text = "";
            password2_txt.Text = "";
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
