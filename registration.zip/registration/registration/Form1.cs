﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace registration
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (name_txt.Text != "" && uname_txt.Text != "" && password_txt.Text != "" && city_txt.Text != "")
            {

                Form2 o = new Form2();
                
                o.uname_lbl.Text = uname_txt.Text;
                o.password_lbl.Text = password_txt.Text;
                o.name_lbl.Text = name_txt.Text;
                o.city_lbl.Text = city_txt.Text;
                o.ShowDialog();                
            }
            else
            {
                MessageBox.Show("not fill the full form");
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
