﻿namespace bmi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.weight_txt = new System.Windows.Forms.TextBox();
            this.cm_txt = new System.Windows.Forms.TextBox();
            this.height_txt = new System.Windows.Forms.TextBox();
            this.bmi_txt = new System.Windows.Forms.TextBox();
            this.kg_txt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(377, 108);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "WEIGHT";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Yellow;
            this.label2.Location = new System.Drawing.Point(377, 231);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "HIEGHT";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Yellow;
            this.label3.Location = new System.Drawing.Point(1001, 231);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "BMI";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(741, 348);
            this.button1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(258, 49);
            this.button1.TabIndex = 3;
            this.button1.Text = "YOUR CATEGORY";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // weight_txt
            // 
            this.weight_txt.Location = new System.Drawing.Point(546, 108);
            this.weight_txt.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.weight_txt.Name = "weight_txt";
            this.weight_txt.Size = new System.Drawing.Size(160, 28);
            this.weight_txt.TabIndex = 4;
            // 
            // cm_txt
            // 
            this.cm_txt.AutoCompleteCustomSource.AddRange(new string[] {
            "centimeter(cm)",
            "meter(m)",
            "inches(ich)",
            "feet(ft)"});
            this.cm_txt.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cm_txt.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.cm_txt.Location = new System.Drawing.Point(767, 231);
            this.cm_txt.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.cm_txt.Name = "cm_txt";
            this.cm_txt.Size = new System.Drawing.Size(173, 28);
            this.cm_txt.TabIndex = 5;
            this.cm_txt.TextChanged += new System.EventHandler(this.cm_txt_TextChanged);
            // 
            // height_txt
            // 
            this.height_txt.Location = new System.Drawing.Point(546, 231);
            this.height_txt.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.height_txt.Name = "height_txt";
            this.height_txt.Size = new System.Drawing.Size(160, 28);
            this.height_txt.TabIndex = 6;
            // 
            // bmi_txt
            // 
            this.bmi_txt.Location = new System.Drawing.Point(1111, 224);
            this.bmi_txt.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.bmi_txt.Name = "bmi_txt";
            this.bmi_txt.Size = new System.Drawing.Size(160, 28);
            this.bmi_txt.TabIndex = 7;
            // 
            // kg_txt
            // 
            this.kg_txt.AutoCompleteCustomSource.AddRange(new string[] {
            "kilogram(kg)",
            "pounds(ps)"});
            this.kg_txt.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.kg_txt.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.kg_txt.Location = new System.Drawing.Point(767, 108);
            this.kg_txt.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.kg_txt.Name = "kg_txt";
            this.kg_txt.Size = new System.Drawing.Size(173, 28);
            this.kg_txt.TabIndex = 9;
            this.kg_txt.TextChanged += new System.EventHandler(this.kg_txt_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1024, 47);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 21);
            this.label4.TabIndex = 10;
            this.label4.Text = "label4";
            this.label4.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1026, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 21);
            this.label5.TabIndex = 11;
            this.label5.Text = "label5";
            this.label5.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(1187, 497);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.kg_txt);
            this.Controls.Add(this.bmi_txt);
            this.Controls.Add(this.height_txt);
            this.Controls.Add(this.cm_txt);
            this.Controls.Add(this.weight_txt);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Yellow;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox weight_txt;
        private System.Windows.Forms.TextBox cm_txt;
        private System.Windows.Forms.TextBox height_txt;
        private System.Windows.Forms.TextBox bmi_txt;
        private System.Windows.Forms.TextBox kg_txt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

