﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace bmi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cm_txt_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void kg_txt_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (cm_txt.Text == "centimeter(cm)")
            {
                label5.Text = Convert.ToDouble(height_txt.Text).ToString();
            }
            else if (cm_txt.Text == "meter(m)")
            {
                label5.Text = (Convert.ToDouble(height_txt.Text) / 0.01000).ToString();
            }
            else if (cm_txt.Text == "inches(inch)")
            {
                label5.Text= (Convert.ToDouble(height_txt.Text) * 2.54).ToString();
            }
            else if (cm_txt.Text == "feet(ft)")
            {
                label5.Text = (Convert.ToDouble(height_txt.Text) / 0.032808).ToString();
            }
            if (kg_txt.Text == "kilogram(kg)")
            {
                label4.Text= Convert.ToDouble(weight_txt.Text).ToString();
            }
            else if (kg_txt.Text == "pounds(ps)")
            {
                label4.Text = (Convert.ToDouble(weight_txt.Text) / 2.2046).ToString();
            }

            bmi_txt.Text = (Convert.ToDouble(label4.Text)/(Convert.ToDouble( label5.Text) *Convert.ToDouble( label5.Text))).ToString();
         
            
        }
        

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        
    }
    
}
