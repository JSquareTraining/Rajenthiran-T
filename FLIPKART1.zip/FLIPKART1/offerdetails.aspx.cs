﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class offerdetails : System.Web.UI.Page
{
    daaaccess da = new daaaccess();
    protected void Page_Load(object sender, EventArgs e)
    {
       
        DataSet ds = new DataSet();
        if (!IsPostBack == true)
        {
            ds = da.fullview();
            DropDownList1.DataTextField = "product_name";
            DropDownList1.DataValueField = "product_name";
            DropDownList1.DataSource = ds.Tables[0].DefaultView;
            DropDownList1.DataBind();
        }
        if (!IsPostBack == true)
        {
            view1();
        }

    }
    public void view1()
    {
        DataSet ds = new DataSet();
        ds = da.offer_view();
        GridView1.DataSource = ds.Tables[0].DefaultView;
        GridView1.DataBind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        da.offer_insert(DropDownList1.Text, TextBox2.Text, TextBox3.Text);
        view1();
    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        view1();
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        view1();
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
       // Label lblpname = (Label)GridView1.Rows[e.RowIndex].FindControl("Label4");
        TextBox txtpname = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox1");
        TextBox txtoffname = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox4");
        TextBox txtoffdur = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox5");
        da.offer_update(txtpname.Text,txtoffname.Text,txtoffdur.Text);
 
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        TextBox txtpname = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox1");
        da.offer_delete(txtpname.Text);
        view1();
    }
}