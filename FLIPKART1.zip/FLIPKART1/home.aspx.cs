﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DataSet ds = new DataSet();
        daaaccess da=new daaaccess();
        if (!IsPostBack == true)
        {
            ds = da.prod_subcategory(Request.QueryString["prtname"]);
            DataList1.DataSource = ds.Tables[0].DefaultView;
            DataList1.DataBind();

        }
    }
}