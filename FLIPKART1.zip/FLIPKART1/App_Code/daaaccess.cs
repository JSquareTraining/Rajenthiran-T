﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for daaaccess
/// </summary>
public class daaaccess
{
    logical log = new logical();
   // SqlDataReader sdr;
	public SqlDataReader row1(string a)
	{
        string s = "select * from  login1 where username='"+a+"'";
        log.query = s;
        return log.row();
	}
    public int insert(string mc, string sc, string pn, int pp, int sp, int sk, string fr, string img)
    {
        string s = "exec product_proc '" + mc + "','" + sc + "','" + pn + "'," + pp + "," + sp + "," + sk + ",'" + fr + "','" + img + "'";
        log.query = s;
        return log.execute();
    }
    
    
    public DataSet fullview()
    {
        DataSet ds = new DataSet();
        string s = "select distinct * from product";
        log.query = s;
        return log.table();
    }
    public DataSet fullview1()
    {
        DataSet ds = new DataSet();
        string s = "select distinct product_name,sub_category from product";
        log.query = s;
        return log.table();
    }
    
    public DataSet cat_view()
    {
        DataSet ds = new DataSet();
        string s = "select distinct * from category";
        log.query = s;
        return log.table();
    }
  
    public int cat_insert(string mc, string sc)
    {
        string s = "insert into category values('" + mc + "','" + sc + "')";
        log.query = s;
        return log.execute();


    }
    public int offer_insert(string pn,string on,string od)
    {
        string s = "insert into offer values('" + pn + "','" + on + "','" + od + "')";
        log.query = s;
        return log.execute();
    }
    public DataSet offer_view()
    {
        string s = "select distinct * from offer";
        log.query = s;
        return log.table();
    }
    public int offer_update(string pn,string od,string on)
    {
        string s = "update offer set offer_name='" + od + "',offer_duration='" + on + "' where product_name='" + pn+ "'";
        log.query = s;
        return log.execute();
    }
    public int offer_delete(string pn)
    {
        string s="delete from offer where product_name='"+pn+"'";
        log.query = s;
        return log.execute();
    }
    public int cat_update(string mc, string sc)
    {
        string s = "update category set sub_category='" + mc + "' where main_category='" + sc + "'";
        log.query = s;
        return log.execute();


    }
    public int cat_delete(string mc)
    {
        string s = "delete from category where main_category='" + mc + "'";
        log.query = s;
        return log.execute();


    }
    public int prod_update(string mc,string sc,string pn,string pp,string sp,string sk,string ft,string img )
    {
        string s = "update product set sub_category='" + sc + "',product_name='" + pn + "',purchase_price='" + pp + "',sales_price='" + sp + "',stock='" + sk + "',feature='" + ft + "',image_upload='" + img + "' where main_caegory='" + mc + "'";
        log.query = s;
        return log.execute();
    }
    public int prod_delete(string mc)
    {
        string s = "delete from product where main_caegory='" + mc + "'";
        log.query = s;
        return log.execute();
    }
    public DataSet prod_subcategory(string n)
    {
        string s = "select * from product where image_upload like '%"+n+"%'";
        log.query = s;
        return log.table();
    }
    public DataSet prod_single(string n)
    {
        string s = "select * from product where product_name='" + n + "'";
        log.query = s;
        return log.table();
    }
        
}