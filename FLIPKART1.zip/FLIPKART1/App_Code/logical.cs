﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for logical
/// </summary>
public class logical
{
    string qry;
    public string query
    {
        get
        {

            return qry;

        }
        set
        {
            qry = value;
        }
    }
    SqlConnection sc = new SqlConnection();
    public void con()
    {
        sc.ConnectionString = ConfigurationManager.ConnectionStrings["con"].ToString();
        sc.Close();
        sc.Open();
    }
    public int execute()
    {
        con();
        SqlCommand cmd = new SqlCommand(qry, sc);
        cmd.ExecuteNonQuery();
        sc.Close();
        return 1;
    }
    public SqlDataReader row()
    {
        con();
        SqlDataReader sdr;
        SqlCommand cmd= new SqlCommand(qry,sc);
        sdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
        return sdr;
    }
  
    public DataSet table()
    {
        sc.Close();
        con();
        DataSet ds = new DataSet();
        SqlDataAdapter sda = new SqlDataAdapter(qry, sc);
        sda.Fill(ds,"temp");
        sc.Close();
        return ds;
    }
    public object single_row()
    {
        con();
        SqlCommand cmd = new SqlCommand(qry,sc);
       object i= cmd.ExecuteScalar();
       return i;
    }
}