﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Drawing;
using System.Data;


public partial class product : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Request.QueryString["main_category"].ToString() != "" && Request.QueryString["sub_category"].ToString() != "")
        //{
        //    DropDownList1.Text = Request.QueryString["main_category"].ToString();
        //    DropDownList2.Text = Request.QueryString["sub_category"].ToString();
        //}
        DataSet ds = new DataSet();
        
        
            ds = da.cat_view();
            DropDownList1.Items.Clear();
            DropDownList1.DataTextField = "main_category";
            DropDownList1.DataValueField = "main_category";
            DropDownList1.DataSource = ds.Tables[0].DefaultView;
            DropDownList1.DataBind();

            DropDownList2.DataTextField = "sub_category";
            DropDownList2.DataValueField = "sub_category";
            DropDownList2.DataSource = ds.Tables[0].DefaultView;
            DropDownList2.DataBind();
            //if (DropDownList1.Text == "CLOTHS")
            //{

            //}

            if (!IsPostBack)
            {


                grid();
            }

    }
    daaaccess da = new daaaccess();
    protected void Button1_Click(object sender, EventArgs e)
    {
        int pp=Convert.ToInt32(TextBox3.Text);
        int sp=Convert.ToInt32(TextBox4.Text);
        int sk=Convert.ToInt32(TextBox5.Text);
        da.insert(DropDownList1.Text, DropDownList2.Text, TextBox2.Text, pp, sp, sk, TextBox6.Text, TextBox2.Text+".jpg");
        FileUpload1.SaveAs(Server.MapPath("~") + "//image//" +TextBox2.Text+".jpg");
        
        grid();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
       
    }
    protected void Button2_Click1(object sender, EventArgs e)
    {
       // FileUpload1.SaveAs(Server.mappath ("~") + "//upload//" + FileUpload1.FileName);
       
       
     
        
    }
    public void grid()
    {
        DataSet ds = new DataSet();
        ds = da.fullview();
        GridView1.DataSource = ds.Tables[0].DefaultView;
        GridView1.DataBind();
    }


    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        grid();
    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        grid();

    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        //TextBox txtmcat = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox");
        TextBox txtmc = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox7");
        TextBox txtscat = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox8");
        TextBox txtpn = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox9");
        TextBox txtpp = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox10");
        TextBox txtsp = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox11");
        TextBox txtstock = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox12");
        TextBox txtftr = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox13");
        TextBox txtimg = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox14");

        da.prod_update(txtmc.Text, txtscat.Text, txtpn.Text, txtpp.Text, txtsp.Text, txtstock.Text, txtftr.Text, txtimg.Text);
        grid();
    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        TextBox txtmc = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox7");
        da.prod_delete(txtmc.Text);
        grid();
    }
}