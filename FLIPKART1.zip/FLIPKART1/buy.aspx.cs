﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class billing : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        daaaccess da=new daaaccess();
        DataSet ds = new DataSet();
        ds = da.prod_single(Request.QueryString["prod_name"]);
        DataList1.DataSource = ds.Tables[0].DefaultView;
        DataList1.DataBind();
    }
    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}