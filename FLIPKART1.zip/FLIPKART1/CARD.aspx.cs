﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class CARD : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DataSet ds=new DataSet();
        ds=da.fullview1();
        GridView1.DataSource = ds.Tables[0].DefaultView;
        GridView1.DataBind();
    }
    daaaccess da = new daaaccess();
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
       // GridView1.EditIndex = e.NewEditIndex;

    }
}