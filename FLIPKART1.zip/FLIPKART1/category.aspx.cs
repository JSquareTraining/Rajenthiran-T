﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class category : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ds = da.cat_view();
            GridView1.DataSource = ds.Tables[0].DefaultView;
            GridView1.DataBind();
        }
       
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedItem.ToString() == "ELECTRONICS")
        {
            DropDownList2.Items.Clear();
            DropDownList2.Items.Add("FAN");
            DropDownList2.Items.Add("WATCH");
            DropDownList2.Items.Add("TV");
           
        }
        else if (DropDownList1.SelectedItem.ToString() == "CLOTHS")
        {
            DropDownList2.Items.Clear();
            DropDownList2.Items.Add("MEN");
            DropDownList2.Items.Add("BABY");
            DropDownList2.Items.Add("GIRLS");
        }
        else if (DropDownList1.SelectedItem.ToString() == "MOBILE")
        {
            DropDownList2.Items.Clear();
            DropDownList2.Items.Add("SAMSUNG");
            DropDownList2.Items.Add("NOKIA");
            DropDownList2.Items.Add("LG");
            DropDownList2.Items.Add("MICROMAX");
            DropDownList2.Items.Add("I PHONE");

        }
        else if (DropDownList1.SelectedItem.ToString() == "LAPTOP")
        {
            DropDownList2.Items.Clear();
            DropDownList2.Items.Add("DELL");
            DropDownList2.Items.Add("HASEE");
            DropDownList2.Items.Add("LENOVO");
            DropDownList2.Items.Add("LG");
            DropDownList2.Items.Add("HCL");

        }
        else if (DropDownList1.SelectedItem.ToString() == "BOOKS")
        {
            DropDownList2.Items.Clear();
            DropDownList2.Items.Add(".NET");
            DropDownList2.Items.Add("JAVA");
            DropDownList2.Items.Add("PHP");
            DropDownList2.Items.Add("ANDROID");
            DropDownList2.Items.Add("C++");

        }
    }
    daaaccess da = new daaaccess();
    DataSet ds = new DataSet();
    protected void Button1_Click(object sender, EventArgs e)
    {
        da.cat_insert(DropDownList1.Text, DropDownList2.Text);

        grid_view();
       // Response.Redirect("product.aspx?main_category="+DropDownList1.Text+"&sub_category="+ DropDownList2.Text);
      // Response.Redirect("product.aspx?m=aa&&s=aa");
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        grid_view();
    }

    public void grid_view()
    {
        ds = da.cat_view();
        GridView1.DataSource = ds.Tables[0].DefaultView;
        GridView1.DataBind();
    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        grid_view();
    }

    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

        TextBox txtmcategory = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox2");
        Label lblscategory = (Label)GridView1.Rows[e.RowIndex].FindControl("Label1");

        da.cat_update(txtmcategory.Text, lblscategory.Text);
        grid_view();
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        Label lblmcategory = (Label)GridView1.Rows[e.RowIndex].FindControl("Label1");
        da.cat_delete(lblmcategory.Text);
        grid_view();
    }
}