﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace discount
{
    public partial class lbl_blns : Form
    {
        public lbl_blns()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "ONLINE SHOPPING";

            AutoCompleteStringCollection app = new AutoCompleteStringCollection();
            app.Add("f.apple");
            app.Add("f.mango");
            app.Add("f.orange");
            txt_frts.AutoCompleteSource = AutoCompleteSource.CustomSource;
            txt_frts.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txt_frts.AutoCompleteCustomSource = app;
           
        }

        private void txt_frts_TextChanged(object sender, EventArgs e)
        {
            if (txt_frts . Text != "")
            {
                textBox7.Enabled = true;
            }
           if (txt_frts.Text == "f.apple")
            {
                textBox4.Text = "100";
            }
            else if (txt_frts.Text == "f.panana")
            {
                textBox4.Text = "50";
            }
            else if (txt_frts.Text == "f.orange")
            {
                textBox4.Text = "70";
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                textBox8.Enabled = true;
            }
            if (textBox1.Text == "s.lux")
            {
                textBox5.Text = "30";
            }

            else if (textBox1.Text == "s.rexsona")
            {
                textBox5.Text = "35";
            }
            else if (textBox1.Text == "s.dove")
            {
                textBox5.Text = "40";
            }

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (textBox3.Text != "")
            {
                textBox9.Enabled = true;
            }
            if (textBox3.Text == "v.carrot")
            {
                textBox6.Text = "20";
            }
            else if (textBox3.Text == "v.tomato")
            {
                textBox6.Text = "15";
            }
            else if (textBox3.Text == "v.onion")
            {
                textBox6.Text = "25";
            }
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

            if (textBox7.Text == "")
            {
                textBox10.Text = "0";
            }
            else
            {
                int i = 0, j = 0, k = 0;

                i = Convert.ToInt32(textBox4.Text);
                j = Convert.ToInt32(textBox7.Text);
                k = i * j;
                textBox10.Text = Convert.ToString(k);

                // int p=0, o=0, m=0, n=0;
                // p =Convert.ToInt32(textBox10.Text);
                // o =Convert.ToInt32(textBox11.Text);
                // m =Convert.ToInt32(textBox12.Text);
                // n = p+ o + m;
                // textBox13.Text = Convert.ToString(n);

            }
            if (textBox10.Text == "")
            {
                textBox13.Text = "";
            }
            else
            {
                textBox13.Text =(Convert .ToInt32 ( textBox10.Text)+Convert .ToInt32 (textBox11 .Text )+Convert .ToInt32 (textBox12 .Text )).ToString ();
            }
        }
        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            if (textBox8.Text == "")
            {
                textBox11.Text = "0";
            }
            else
            {
                int i, j, k;
                i = Convert.ToInt32(textBox8.Text);
                j = Convert.ToInt32(textBox5.Text);
                k = i * j;
                textBox11.Text = Convert.ToString(k);

            }
            if (textBox10.Text == "")
            {
                textBox13.Text = "";
            }
            else
            {
                textBox13.Text = (Convert.ToInt32(textBox10.Text) + Convert.ToInt32(textBox11.Text) + Convert.ToInt32(textBox12.Text)).ToString();
            }

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

            if (textBox9.Text == "")
            {
                textBox12.Text = "0";
            }
            else
            {
                int i, j, k;
                i = Convert.ToInt32(textBox9.Text);
                j = Convert.ToInt32(textBox6.Text);
                k = i * j;
                textBox12.Text = Convert.ToString(k);
                textBox13.Text = textBox12.Text;
            }
            if (textBox10.Text == "")
            {
                textBox13.Text = "";
            }
            else
            {
                textBox13.Text = (Convert.ToInt32(textBox10.Text) + Convert.ToInt32(textBox11.Text) + Convert.ToInt32(textBox12.Text)).ToString();
            }

        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {
           // int i=0, j=0, k=0, l=0;
           // i = Convert.ToInt32(textBox10.Text);
          //  j = Convert.ToInt32(textBox11.Text);
          //  k = Convert.ToInt32(textBox12.Text);
          //  l = i + j + k;
          //  textBox13.Text = Convert.ToString(l);

        }

        private void textBox14_TextChanged(object sender, EventArgs e)
        {
            if (textBox14.Text == "")
            {
                textBox15.Text = "";
            }
            else
            {
                textBox15.Text = (Convert.ToInt32(textBox13.Text) * Convert.ToInt32(textBox14.Text) / 100).ToString();
                textBox16.Text = (Convert.ToInt32(textBox13.Text) - Convert.ToInt32(textBox15.Text)).ToString();
            }

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
            {
                textBox17.Text = (Convert.ToInt32(textBox2.Text) - Convert.ToInt32(textBox16.Text)).ToString();
            }
            else
            {
                textBox2.Text = "0";
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
    }
}