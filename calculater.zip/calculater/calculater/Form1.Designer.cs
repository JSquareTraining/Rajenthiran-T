﻿namespace calculater
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_fv = new System.Windows.Forms.TextBox();
            this.lbl_sv = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_1 = new System.Windows.Forms.Button();
            this.btn_2 = new System.Windows.Forms.Button();
            this.btn_3 = new System.Windows.Forms.Button();
            this.btn_4 = new System.Windows.Forms.Button();
            this.btn_5 = new System.Windows.Forms.Button();
            this.btn_6 = new System.Windows.Forms.Button();
            this.btn_7 = new System.Windows.Forms.Button();
            this.btn_8 = new System.Windows.Forms.Button();
            this.btn_9 = new System.Windows.Forms.Button();
            this.btn_0 = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.btn_dot = new System.Windows.Forms.Button();
            this.btn_min = new System.Windows.Forms.Button();
            this.btn_mul = new System.Windows.Forms.Button();
            this.btn_div = new System.Windows.Forms.Button();
            this.btn_eql = new System.Windows.Forms.Button();
            this.btn_clr = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_fv
            // 
            this.lbl_fv.Location = new System.Drawing.Point(205, 46);
            this.lbl_fv.Name = "lbl_fv";
            this.lbl_fv.Size = new System.Drawing.Size(100, 22);
            this.lbl_fv.TabIndex = 0;
            // 
            // lbl_sv
            // 
            this.lbl_sv.Location = new System.Drawing.Point(363, 43);
            this.lbl_sv.Name = "lbl_sv";
            this.lbl_sv.Size = new System.Drawing.Size(100, 22);
            this.lbl_sv.TabIndex = 2;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(521, 41);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(111, 22);
            this.textBox5.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Location = new System.Drawing.Point(311, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 22);
            this.label1.TabIndex = 5;
            this.label1.Click += new System.EventHandler(this.lbl);
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Location = new System.Drawing.Point(469, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 24);
            this.label2.TabIndex = 6;
            // 
            // btn_1
            // 
            this.btn_1.Location = new System.Drawing.Point(205, 140);
            this.btn_1.Name = "btn_1";
            this.btn_1.Size = new System.Drawing.Size(43, 41);
            this.btn_1.TabIndex = 7;
            this.btn_1.Text = "1";
            this.btn_1.UseVisualStyleBackColor = true;
            this.btn_1.Click += new System.EventHandler(this.btn);
            // 
            // btn_2
            // 
            this.btn_2.Location = new System.Drawing.Point(278, 140);
            this.btn_2.Name = "btn_2";
            this.btn_2.Size = new System.Drawing.Size(43, 41);
            this.btn_2.TabIndex = 8;
            this.btn_2.Text = "2";
            this.btn_2.UseVisualStyleBackColor = true;
            this.btn_2.Click += new System.EventHandler(this.btn);
            // 
            // btn_3
            // 
            this.btn_3.Location = new System.Drawing.Point(364, 140);
            this.btn_3.Name = "btn_3";
            this.btn_3.Size = new System.Drawing.Size(43, 41);
            this.btn_3.TabIndex = 9;
            this.btn_3.Text = "3";
            this.btn_3.UseVisualStyleBackColor = true;
            this.btn_3.Click += new System.EventHandler(this.btn);
            // 
            // btn_4
            // 
            this.btn_4.Location = new System.Drawing.Point(205, 211);
            this.btn_4.Name = "btn_4";
            this.btn_4.Size = new System.Drawing.Size(43, 41);
            this.btn_4.TabIndex = 10;
            this.btn_4.Text = "4";
            this.btn_4.UseVisualStyleBackColor = true;
            this.btn_4.Click += new System.EventHandler(this.btn);
            // 
            // btn_5
            // 
            this.btn_5.Location = new System.Drawing.Point(278, 211);
            this.btn_5.Name = "btn_5";
            this.btn_5.Size = new System.Drawing.Size(43, 41);
            this.btn_5.TabIndex = 11;
            this.btn_5.Text = "5";
            this.btn_5.UseVisualStyleBackColor = true;
            this.btn_5.Click += new System.EventHandler(this.btn);
            // 
            // btn_6
            // 
            this.btn_6.Location = new System.Drawing.Point(364, 211);
            this.btn_6.Name = "btn_6";
            this.btn_6.Size = new System.Drawing.Size(43, 41);
            this.btn_6.TabIndex = 12;
            this.btn_6.Text = "6";
            this.btn_6.UseVisualStyleBackColor = true;
            this.btn_6.Click += new System.EventHandler(this.btn);
            // 
            // btn_7
            // 
            this.btn_7.Location = new System.Drawing.Point(205, 279);
            this.btn_7.Name = "btn_7";
            this.btn_7.Size = new System.Drawing.Size(43, 41);
            this.btn_7.TabIndex = 13;
            this.btn_7.Text = "7";
            this.btn_7.UseVisualStyleBackColor = true;
            this.btn_7.Click += new System.EventHandler(this.btn);
            // 
            // btn_8
            // 
            this.btn_8.Location = new System.Drawing.Point(278, 279);
            this.btn_8.Name = "btn_8";
            this.btn_8.Size = new System.Drawing.Size(43, 41);
            this.btn_8.TabIndex = 14;
            this.btn_8.Text = "8";
            this.btn_8.UseVisualStyleBackColor = true;
            this.btn_8.Click += new System.EventHandler(this.btn);
            // 
            // btn_9
            // 
            this.btn_9.Location = new System.Drawing.Point(364, 279);
            this.btn_9.Name = "btn_9";
            this.btn_9.Size = new System.Drawing.Size(43, 41);
            this.btn_9.TabIndex = 15;
            this.btn_9.Text = "9";
            this.btn_9.UseVisualStyleBackColor = true;
            this.btn_9.Click += new System.EventHandler(this.btn);
            // 
            // btn_0
            // 
            this.btn_0.Location = new System.Drawing.Point(435, 279);
            this.btn_0.Name = "btn_0";
            this.btn_0.Size = new System.Drawing.Size(43, 41);
            this.btn_0.TabIndex = 16;
            this.btn_0.Text = "0";
            this.btn_0.UseVisualStyleBackColor = true;
            this.btn_0.Click += new System.EventHandler(this.btn);
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(435, 140);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(43, 41);
            this.btn_add.TabIndex = 17;
            this.btn_add.Text = "+";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.lbl);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(435, 211);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(43, 41);
            this.button12.TabIndex = 18;
            this.button12.Text = "button12";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // btn_dot
            // 
            this.btn_dot.Location = new System.Drawing.Point(435, 212);
            this.btn_dot.Name = "btn_dot";
            this.btn_dot.Size = new System.Drawing.Size(43, 41);
            this.btn_dot.TabIndex = 19;
            this.btn_dot.Text = ".";
            this.btn_dot.UseVisualStyleBackColor = true;
            this.btn_dot.Click += new System.EventHandler(this.btn);
            // 
            // btn_min
            // 
            this.btn_min.Location = new System.Drawing.Point(508, 140);
            this.btn_min.Name = "btn_min";
            this.btn_min.Size = new System.Drawing.Size(43, 41);
            this.btn_min.TabIndex = 20;
            this.btn_min.Text = "-";
            this.btn_min.UseVisualStyleBackColor = true;
            this.btn_min.Click += new System.EventHandler(this.lbl);
            // 
            // btn_mul
            // 
            this.btn_mul.Location = new System.Drawing.Point(508, 212);
            this.btn_mul.Name = "btn_mul";
            this.btn_mul.Size = new System.Drawing.Size(43, 41);
            this.btn_mul.TabIndex = 21;
            this.btn_mul.Text = "*";
            this.btn_mul.UseVisualStyleBackColor = true;
            this.btn_mul.Click += new System.EventHandler(this.lbl);
            // 
            // btn_div
            // 
            this.btn_div.Location = new System.Drawing.Point(508, 279);
            this.btn_div.Name = "btn_div";
            this.btn_div.Size = new System.Drawing.Size(43, 41);
            this.btn_div.TabIndex = 22;
            this.btn_div.Text = "/";
            this.btn_div.UseVisualStyleBackColor = true;
            this.btn_div.Click += new System.EventHandler(this.lbl);
            // 
            // btn_eql
            // 
            this.btn_eql.Location = new System.Drawing.Point(589, 211);
            this.btn_eql.Name = "btn_eql";
            this.btn_eql.Size = new System.Drawing.Size(43, 109);
            this.btn_eql.TabIndex = 23;
            this.btn_eql.Text = "=";
            this.btn_eql.UseVisualStyleBackColor = true;
            this.btn_eql.Click += new System.EventHandler(this.btn_eql_Click);
            // 
            // btn_clr
            // 
            this.btn_clr.ForeColor = System.Drawing.Color.Red;
            this.btn_clr.Location = new System.Drawing.Point(582, 140);
            this.btn_clr.Name = "btn_clr";
            this.btn_clr.Size = new System.Drawing.Size(50, 41);
            this.btn_clr.TabIndex = 24;
            this.btn_clr.Text = "clear";
            this.btn_clr.UseVisualStyleBackColor = true;
            this.btn_clr.Click += new System.EventHandler(this.btn_clr_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(913, 464);
            this.Controls.Add(this.btn_clr);
            this.Controls.Add(this.btn_eql);
            this.Controls.Add(this.btn_div);
            this.Controls.Add(this.btn_mul);
            this.Controls.Add(this.btn_min);
            this.Controls.Add(this.btn_dot);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.btn_0);
            this.Controls.Add(this.btn_9);
            this.Controls.Add(this.btn_8);
            this.Controls.Add(this.btn_7);
            this.Controls.Add(this.btn_6);
            this.Controls.Add(this.btn_5);
            this.Controls.Add(this.btn_4);
            this.Controls.Add(this.btn_3);
            this.Controls.Add(this.btn_2);
            this.Controls.Add(this.btn_1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.lbl_sv);
            this.Controls.Add(this.lbl_fv);
            this.Name = "Form1";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Click += new System.EventHandler(this.btn);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox lbl_fv;
        private System.Windows.Forms.TextBox lbl_sv;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_1;
        private System.Windows.Forms.Button btn_2;
        private System.Windows.Forms.Button btn_3;
        private System.Windows.Forms.Button btn_4;
        private System.Windows.Forms.Button btn_5;
        private System.Windows.Forms.Button btn_6;
        private System.Windows.Forms.Button btn_7;
        private System.Windows.Forms.Button btn_8;
        private System.Windows.Forms.Button btn_9;
        private System.Windows.Forms.Button btn_0;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button btn_dot;
        private System.Windows.Forms.Button btn_min;
        private System.Windows.Forms.Button btn_mul;
        private System.Windows.Forms.Button btn_div;
        private System.Windows.Forms.Button btn_eql;
        private System.Windows.Forms.Button btn_clr;
    }
}

