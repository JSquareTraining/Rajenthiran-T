﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace calculater
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btn(object sender, EventArgs e)
        {
            Button btn1 = (Button)sender;
            if (label1.Text == "")
            {

                lbl_fv.Text += btn1.Text;

            }
            else
            {
                // Button btn2 = (Button)sender;
                lbl_sv.Text += btn1.Text;

            }
        }
        private void lbl(object sender, EventArgs e)
        {
            Button lbl1 = (Button)sender;
            label1.Text = lbl1.Text;

        }
        private void btnn(object sender, EventArgs e)
        {
            // Button btn2 = (Button)sender;
            //lbl_sv.Text += btn2.Text;
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_eql_Click(object sender, EventArgs e)
        {
            label2.Text = "=";


            if (label1.Text == "+")
            {
                if (lbl_fv.Text == "")
                {
                    lbl_fv.Text = "0";
                    textBox5.Text = (Convert.ToDouble(lbl_fv.Text) + Convert.ToDouble(lbl_sv.Text)).ToString();

                }
                else
                {


                    textBox5.Text = (Convert.ToDouble(lbl_fv.Text) + Convert.ToDouble(lbl_sv.Text)).ToString();
                }
            }


            else if (label1.Text == "-")
            {
                if (lbl_fv.Text == "")
                {
                    lbl_fv.Text = "0";
                    textBox5.Text = (Convert.ToDouble(lbl_fv.Text) - Convert.ToDouble(lbl_sv.Text)).ToString();

                }
                else
                {
                    textBox5.Text = (Convert.ToDouble(lbl_fv.Text) - Convert.ToDouble(lbl_sv.Text)).ToString();

                }
            }
            else if (label1.Text == "*")
            {
                if (lbl_fv.Text == "")
                {
                    lbl_fv.Text = "0";
                    textBox5.Text = (Convert.ToDouble(lbl_fv.Text) * Convert.ToDouble(lbl_sv.Text)).ToString();

                }
                else
                {
                    textBox5.Text = (Convert.ToDouble(lbl_fv.Text) * Convert.ToDouble(lbl_sv.Text)).ToString();
                }
            }

            else if (label1.Text == "/")
            {
                if (lbl_fv.Text == "")
                {
                    lbl_fv.Text = "0";
                    textBox5.Text = (Convert.ToDouble(lbl_fv.Text) / Convert.ToDouble(lbl_sv.Text)).ToString();

                }
                else
                {
                    textBox5.Text = (Convert.ToDouble(lbl_fv.Text) / Convert.ToDouble(lbl_sv.Text)).ToString();
                }
            }
        }




        private void btn_clr_Click(object sender, EventArgs e)
        {

            btn_clr.Text = "";

            lbl_fv.Text = btn_clr.Text;
            label1.Text = btn_clr.Text;
            lbl_sv.Text = btn_clr.Text;
            label2.Text = btn_clr.Text;
            textBox5.Text = btn_clr.Text;
            btn_clr.Text = "clear";
        }

    }
}
